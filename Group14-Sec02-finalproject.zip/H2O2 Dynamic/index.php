<?php require 'php/header.php';?>
<!doctype html>
<html lang="en">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="keywords" content="Coupon, Yousef, Mowfaq, Khalid, Hussain, H2O2, Offer, deal, shopping, shop">
        <meta name="description" content="A tailormade experience for your shopping leasiure where you may find all kinds of coupons and offers that will fulfill your needs">
        <meta name="author" content="Yousef Taj, Khalid AlAmro, Mowfaq Wale, Hussain Alzayer">
        <link rel="icon" href="img/TabIcon.svg">

        <title>H2O2 Coupon - Main Page</title>
    </head>

    <body>
        
        <!-- This will contain the body of the page -->
        <div class="in-container d-none d-lg-block">
            <div class="picture fade-in">
                <a href="/php/amazon.php"><img src="/img/cashier-hero.png" class="carPic d-block w-100" alt="Amazon"></a>
                <div class="overlay text-light">
                    <p class="heading">Welcome to H2O2 Coupon!</p>
                    <p class="text-intro">Start your savings trip here where we will exceed your <br> expectations with a store waiting for you around <br> every courner that is sure to fit your needs.</p>
                    <a href="/php/stores.php" class="btn fade-in" role="button" aria-pressed="true"><p class=py-auto>Stores Page</p></a>
                </div>
            </div>
            <div class="showcase-container-first">
                <a href="/php/amazon.php">
                    <img class="showcase-first" src="img/showcase.jpg">
                </a>
                <div class="showcase-overlay">
                    <a href="/php/amazon.php" class="showcase-text">Check out deals that are sure to catch your eyes on Amazon!</a>
                </div>
            </div>
            <div class="showcase-container-second">
                <a href="/php/jarir.php">
                    <img class="showcase-second" src="img/showcase2.jpg">
                </a>
                <div class="showcase-overlay">
                    <a href="/php/jarir.php" class="showcase-text">Let us give you an insight on what to buy from Jarir!</a>
                </div>
            </div>
            <div class="showcase-container-third">
                <a href="/php/hungerstation.php">
                    <img class="showcase-third" src="img/showcase3.jpg">
                </a>
                <div class="showcase-overlay">
                    <a href="/php/hungerstation.php" class="showcase-text">Save on your next food delivery from hungerstation!</a>
                </div>
            </div>
        </div>
        
        <div class="container-fluid d-none d-lg-block">
            <hr>
            <!-- This part contains all the most viewed stores and coupons -->
            <div class="container-fluid mx-auto align-content-center">
            <div class="row ">
            <?php include 'php/couponcards.php'; ?>
            </div>
            </div>
        </div>
        <div class="container px-0 py-0 d-lg-none">
            <div class="row mx-auto text-center pt-2 py-0 w-100">
            <div class="col mx-auto fade-in">
                <a href="/php/amazon.php">
                    <img class="img-thumbnail rounded-circle" width="100" src="img/amazon.jpg">
                </a>
            </div>
            <div class="col mx-auto fade-in">
                <a href="/php/jarir.php">
                    <img class="img-thumbnail rounded-circle" width="100" src="img/jarir.jpg">
                </a>
            </div>
            <div class="col mx-auto fade-in">
                <a href="/php/hungerstation.php">
                    <img class="img-thumbnail rounded-circle" width="100" src="img/hungerstation.png">
                </a>
            </div>
            <a href="/php/stores.php" class="btn btn-stores mt-2 fade-in" role="button" aria-pressed="true"><p class="pt-2">Stores Page</p></a>
        </div>
        <div class="container">
            <hr>
            <!-- This part contains all the most viewed stores and coupons -->
            <div class="container-fluid mx-auto align-content-center">
            <div class="row ">
            <?php include 'php/couponcards.php'; ?>
            </div>
        </div>
        </div>
        </div>
        <?php require 'php/footer.php';?>
        
        
        <!-- Bootstrap & Personal CSS -->
        <link rel="stylesheet" href="/css/bootstrap.min.css">
        <link rel="stylesheet" href="/css/style.css">
        <link rel="stylesheet" href="/css/sb-admin-2.css">
        <script src="jquery-3.5.1.min.js"></script>
    </body>
</html>