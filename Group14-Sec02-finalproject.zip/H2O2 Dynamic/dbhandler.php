<?php
        
    $host="localhost";
    $password="-sle_]tk+t_b3+H_";
    $dbname="id15525273_couponsite";
    $conn=mysqli_connect($host,"id15525273_h2o2",$password,$dbname);
    if(!$conn)
        {
        die('Could not Connect MySql Server:' .mysql_error());
        }
?>