<?php
            require 'dbdetails.php';
             if(isset($_GET["type"], $_GET["id"])) { 
                 $type=$_GET["type"];
                 $id=$_GET["id"];
                 if($type=='like'){
                    $check = "SELECT isLike FROM coupon_impression WHERE CouponID='$id' AND UserID=".$_SESSION['id']."";
                    $checkresult = mysqli_query($conn, $check);
                    $row = mysqli_fetch_array($checkresult);
                    if($row['isLike']=="0"){
                        $delete = "DELETE FROM coupon_impression WHERE CouponID='$id' AND UserID=".$_SESSION['id']."";
                        mysqli_query($conn, $delete);
                        $sql = "INSERT INTO coupon_impression(CouponID,UserID,isLike) VALUES ('$id',".$_SESSION['id'].",'1')";
                        mysqli_query($conn, $sql);
                        echo "<meta http-equiv='refresh' content='1'>";
                    } else if ($row['isLike']!="1"){
                        $sql = "INSERT INTO coupon_impression(CouponID,UserID,isLike) VALUES ('$id',".$_SESSION['id'].",'1')";
                        mysqli_query($conn, $sql);
                        echo "<meta http-equiv='refresh' content='1'>";
                    }
                 } else{ 
                    $check = "SELECT isLike FROM coupon_impression WHERE CouponID='$id' AND UserID=".$_SESSION['id']."";
                    $checkresult = mysqli_query($conn, $check);
                    $row = mysqli_fetch_array($checkresult);
                    if($row['isLike']=="1"){
                        $delete = "DELETE FROM coupon_impression WHERE CouponID='$id' AND UserID=".$_SESSION['id']."";
                        mysqli_query($conn, $delete);
                        $sql = "INSERT INTO coupon_impression(CouponID,UserID,isLike) VALUES ('$id',".$_SESSION['id'].",'0')";
                        mysqli_query($conn, $sql);
                        echo "<meta http-equiv='refresh' content='1'>";
                    } else if ($row['isLike']!="0"){
                        $sql = "INSERT INTO coupon_impression(CouponID,UserID,isLike) VALUES ('$id',".$_SESSION['id'].",'0')";
                        mysqli_query($conn, $sql);
                        echo "<meta http-equiv='refresh' content='1'>";
                    }         
             }  
            }
?>