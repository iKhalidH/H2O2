 <!-- Footer -->
        <footer class="text-center page-footer font-small mx-auto mt-3 web-footer fade-in">
            <a class="btn mx-auto" href="https://twitter.com/CouponH2" target="_blank">
            <img src="/img/twitter.svg" alt="twitter logo" width="40" height="40">
            </a>
            <a class="btn mx-auto" href="https://www.instagram.com/h2o2coupon/" target="_blank">
            <img src="/img/instagram.svg" alt="instagram logo" width="40" height="40">
            </a>
            <button class="btn mx-auto" href="">
            <img src="/img/youtube.svg" alt="youtube logo" width="40" height="40">
            </button>
            <!-- Copyright -->
            <div class="footer-copyright text-center py-3">© 2020 Copyright:
            <a href="https://mdbootstrap.com/"> MDBootstrap.com</a>
            <br>
            Icons made by <a href=" https://www.flaticon.com/authors/freepik" title="Freepik">Freepik</a> from <a href="https://www.flaticon.com/" title="Flaticon"> www.flaticon.com</a>
            <br>
            © 2020 H2O2 All Rights Reserved
            </div>
            <!-- Copyright -->
        </footer>
        <!-- Footer -->