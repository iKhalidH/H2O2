<?php
//Removes from admin table
if(isset($_POST["delete"])) {
    require_once 'dbdetails.php';
    $id = $_POST["AdminID"];
    $stm = "DELETE FROM `admin` WHERE AdminID = '$id';"; 

    $query = mysqli_query($conn, $stm);
    if($query) {
        header("location: adminList.php");
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ADMIN PANEL</title>
    <link rel="icon" href="img/TabIcon.svg">
    
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="/css/adminStyle.css">
</head>
<body>



    <body>
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
        <script src="tabs.js"></script>
        <!-- JavaScript Search Function -->
        <script src="/js/SearchFunctions.js"></script>
    
        <div class="d-flex" id="wrapper">

        <?php
            require('sidenavAdmin.php');
        ?>

        <!-- Page Content -->
        <div id="page-content-wrapper">

            <nav class="navbar navbar-expand-lg navbar-light bg-light pb-2 border-bottom">
                <span class="navbar-toggler-icon" id="menu-toggle"></span>

                <a class="navbar-brand mx-auto" href=""><img src="/img/h202logo.svg" width="50" alt="Logo">H2O2 Dashboard</a>
            </nav>

            <nav class="navbar navbar-expand-lg fade-in align-content-center">           
            <form class="form-inline w-100 mx-auto my-2 my-lg-0">
                <div class="input-group mt-2 mx-auto w-75">
                <input class="form-control mx-auto"type="search" placeholder="Search Admins" id="couponSearch" onkeyup="search()">
                    <select class="nav-item dropdown mx-auto" name="searchOption" id="couponSearchOpt">
                        <option value="0">ID</option>
                        <option value="1">Username</option>
                        <option value="2">Email</option>
                    </select>
                </div>
            </form>
            </nav>
            <div class="container mx-auto pb-4 pt-2">
                <div class="table-responsive rounded-table shadow">
                <table class="table table-hover" id="tb">
                    <thead class="thead text-light shadow">
                        <tr>
                            <th scope="col">Admin ID</th>
                            <th scope="col">Username</th>
                            <th scope="col">Email</th>
                            <th scope="col">Account Status</th>
                            <th scope="col">Remove Admin</th>
                        </tr>
                    </thead>
                    <?php
                    require_once 'dbdetails.php';
                    $userSelect = "SELECT a.AdminID, u.Name, u.Email, u.Account_Status FROM `admin` a, users u WHERE a.AdminID = u.ID";
                    $query = mysqli_query($conn, $userSelect);
                    if (mysqli_num_rows($query) > 0) {
                        while ($tb = mysqli_fetch_array($query)) {



                    ?>
                        <tbody>
                            <tr>
                                <td><?php echo $tb["AdminID"]; ?></td>
                                <td><?php echo $tb["Name"]; ?></td>
                                <td><?php echo $tb["Email"]; ?></td>
                                <td><?php echo $tb["Account_Status"]; ?></td>
                                <td>
                                    <form action="adminList.php" method="POST">
                                        <input type="hidden" name="AdminID" value="<?php echo $tb["AdminID"]; ?>">
                                        <button class="btn btn-danger shadow" type="submit" name="delete" onclick="return confirm('Are you sure you want to continue?');"><img src="/img/trash.svg" width="20" alt=""></button>
                                    </form>
                                </td>
                            </tr>
                    <?php

                        }
                    }
                    ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <!-- /#wrapper -->

        <!-- Bootstrap core JavaScript -->
        <script src="vendor/jquery/jquery.min.js"></script>
        <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

        <!-- Menu Toggle Script -->
        <script>
            $("#menu-toggle").click(function(e) {
            e.preventDefault();
            $("#wrapper").toggleClass("toggled");
            });
        </script>   
    </body>
</html>