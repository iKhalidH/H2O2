<?php
include 'dbdetails.php';
session_start();

$Store_name = mysqli_real_escape_string ($conn, $_POST['Store_name']);
$Store_website = mysqli_real_escape_string ($conn, $_POST['Store_website']);
$Store_reason = mysqli_real_escape_string ($conn, $_POST['Store_reason']);
$Submitter_ID = $_SESSION['id'];

$sql = "INSERT INTO request 
(Submitter_ID, Title, Request_Desc, Address, Status) VALUES
('$Submitter_ID', '$Store_name', '$Store_reason', '$Store_website', '0')";

if(mysqli_query($conn, $sql)) {
echo "Records inserted successfully.";
header("location:../php/requestStore.php");
} else {
echo "ERROR: Could not able to execute sql . ". mysqli_error($conn);
}
?>