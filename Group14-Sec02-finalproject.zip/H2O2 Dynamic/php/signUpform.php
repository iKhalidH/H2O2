<?php
session_start();
$error = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (empty($_POST['name']) || empty($_POST['password']) || empty($_POST['passCon']) || empty($_POST['email'])) {
        $error = "name or password or email are required";
    } else {
        require("dbdetails.php");
        $psw = mysqli_real_escape_string($conn, $_POST['password']);
        $psw2 = mysqli_real_escape_string($conn, $_POST['passCon']);
        $name = mysqli_real_escape_string($conn, $_POST['name']);
        $email = mysqli_real_escape_string($conn, $_POST['email']);
        if ($psw == $psw2) {
            $checkregistered = "SELECT Email FROM users where Email='$email'";
            $result = mysqli_query($conn, $checkregistered) or
            die(mysqli_error($conn));
            $count = mysqli_num_rows($result);
            if ($count == 1) {
                echo "Sign up information is already registered";
            } else {
                $hashedPassword = password_hash($psw, PASSWORD_BCRYPT);
                $sql = "INSERT INTO users(Name,Email,Password,Creation_Date,Account_Status) VALUES ('$name','$email','$hashedPassword',curdate(),'1')";
                $result2 = mysqli_query($conn, $sql);
                $_SESSION['name'] = $_POST['name'];
                $getuserid = "SELECT ID FROM users where Email='$email'";
                $result3 = mysqli_query($conn, $getuserid);
                $row = mysqli_fetch_array($result3);
                if (is_array($row)){
                    $_SESSION['id']=$row['ID'];
                }
                header("location:../index.php");
            }

        } else {
            echo "Password and Password confirmation are not identical.";
        }

    }
} else {
    echo "you are not authorized to access this page";
}

?>