<?php
//Removes from admin table
if(isset($_POST["delete"])) {
    require_once 'dbdetails.php';
    $id = $_POST["AdminID"];
    $stm = "DELETE FROM `admin` WHERE AdminID = '$id';"; 

    $query = mysqli_query($conn, $stm);
    if($query) {
        header("location: adminList.php");
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ADMIN PANEL</title>
    <link rel="icon" href="img/TabIcon.svg">
    
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="/css/adminStyle.css">
</head>
<body>



    <body>
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
        <script src="tabs.js"></script>
        <!-- JavaScript Search Function -->
        <script src="/js/SearchFunctions.js"></script>
    
        <div class="d-flex" id="wrapper">

        <?php
            require('sidenavAdmin.php');
        ?>

        <!-- Page Content -->
        <div id="page-content-wrapper">

            <nav class="navbar navbar-expand-lg navbar-light bg-light pb-2 border-bottom">
                <span class="navbar-toggler-icon" id="menu-toggle"></span>

                <a class="navbar-brand mx-auto" href=""><img src="/img/h202logo.svg" width="50" alt="Logo">H2O2 Dashboard</a>
            </nav>
            
            <div class="container mx-auto py-3 pt-2">
                <div class="table-responsive rounded-table shadow">
                <table class="table table-hover text-center" id="tb">
                    <thead class="thead text-light shadow">
                        <tr>
                            <th scope="col">Users</th>
                            <th scope="col">Admins</th>
                            <th scope="col">Technicians</th>
                            <th scope="col">Stores</th>
                            <th scope="col">Categories</th>
                            <th scope="col">Coupons</th>
                            <th scope="col">Requests</th>
                        </tr>
                    </thead>
                    <?php
                    require_once 'dbdetails.php';
                    $userNum = mysqli_query($conn,"SELECT COUNT(*) as total1 FROM users");
                    $data1=mysqli_fetch_assoc($userNum);
                    $adminNum = mysqli_query($conn,"SELECT COUNT(*) as total2 FROM admin");
                    $data2=mysqli_fetch_assoc($adminNum);
                    $techNum = mysqli_query($conn,"SELECT COUNT(*) as total3 FROM technician");
                    $data3=mysqli_fetch_assoc($techNum);
                    $storeNum = mysqli_query($conn,"SELECT COUNT(*) as total4 FROM store");
                    $data4=mysqli_fetch_assoc($storeNum);
                    $catNum = mysqli_query($conn,"SELECT COUNT(*) as total5 FROM category");
                    $data5=mysqli_fetch_assoc($catNum);
                    $couponNum = mysqli_query($conn,"SELECT COUNT(*) as total6 FROM coupon");
                    $data6=mysqli_fetch_assoc($couponNum);
                    $requestedNum = mysqli_query($conn,"SELECT COUNT(*) as total7 FROM request");
                    $data7=mysqli_fetch_assoc($requestedNum);
                                    ?>
                        <tbody>
                            <tr>
                                <td><?php echo $data1["total1"]; ?></td>
                                <td><?php echo $data2["total2"]; ?></td>
                                <td><?php echo $data3["total3"]; ?></td>
                                <td><?php echo $data4["total4"]; ?></td>
                                <td><?php echo $data5["total5"]; ?></td>
                                <td><?php echo $data6["total6"]; ?></td>
                                <td><?php echo $data7["total7"]; ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <!-- /#wrapper -->

        <!-- Bootstrap core JavaScript -->
        <script src="vendor/jquery/jquery.min.js"></script>
        <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

        <!-- Menu Toggle Script -->
        <script>
            $("#menu-toggle").click(function(e) {
            e.preventDefault();
            $("#wrapper").toggleClass("toggled");
            });
        </script>   
    </body>
</html>