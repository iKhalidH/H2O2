<!-- Sidebar -->
<div class="bg-light border-right" id="sidebar-wrapper">
    <div class="sidebar-heading mt-2">User Panel</div>
        <div class="list-group list-group-flush">
            <a class="list-group-item list-group-item-action" href="/index.php">
                <div class="float-left">
                    <img width="20" src="/img/home.svg" alt="">
                    Home
                </div>
            </a>
            <a class="list-group-item list-group-item-action" href="favouriteStores.php">
                <div class="float-left">    
                    <img width="20" src="../img/star.svg" alt="coupon">
                    Favourite Stores
                </div>
            </a>    
            <a class="list-group-item list-group-item-action mb-0" href="#collapseExample" data-toggle="collapse" aria-haspopup="true" aria-expanded="false">
            <div class="float-left">    
                    <img width="20" src="../img/edit.svg" alt="coupon">
                    Edit profile
                </div>
</a>
                <div class="collapse" id="collapseExample">
    <a class="list-group-item list-group-item-action" id="dname" href="name.php">Edit Display name</a>
    <a class="list-group-item list-group-item-action" id="email" href="email.php">Edit email</a>
    <a class="list-group-item list-group-item-action" id="password" href="password.php">Edit password</a>
  </div>


<a class="list-group-item list-group-item-action" href="requestStore.php">
                <div class="float-left">    
                    <img width="20" src="../img/requestIcon.svg" alt="coupon">
                    Requests
                </div> 
</a>       
        </div>
    </div>
    <!-- /#sidebar-wrapper -->



