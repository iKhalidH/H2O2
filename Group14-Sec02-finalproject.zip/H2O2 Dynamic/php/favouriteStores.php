<?php 
session_start();
         if(!isset($_SESSION['name'])){
echo "You are not authorized to enter this page";
exit;                
  }
  $id=$_SESSION['id'];
?>
<?php require 'dbdetails.php';?>

        
        <!-- Bootstrap & Personal CSS -->
        <link rel="stylesheet" href="/css/bootstrap.min.css">
        <link rel="stylesheet" href="/css/style.css">
<script src="jquery-3.5.1.min.js"></script>

        <title>Profile</title>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="keywords" content="Coupon, Yousef, Mowfaq, Khalid, H2O2, Offer, deal, shopping, shop">
    <meta name="description" content="A tailormade experience for your shopping leasiure where you may find all kinds of coupons and offers that will fulfill your needs">
    <meta name="author" content="Yousef Taj, Khalid AlAmro, Mowfaq Wale">
    <link rel="icon" href="img/TabIcon.svg">
    <title>Favourite Stores</title>
    
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/adminStyle.css">
</head>
<body>

        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
        <script src="tabs.js"></script>
        <!-- JavaScript Search Function -->
        <script src="js/UserSearch.js"></script>
    
        <div class="d-flex" id="wrapper">

        <?php
            require('sidenavuser.php');
        ?>

        <!-- Page Content -->
        <div id="page-content-wrapper">

            <nav class="navbar navbar-expand-lg navbar-light bg-light pb-2 border-bottom">
                <span class="navbar-toggler-icon" id="menu-toggle"></span>

                <a class="navbar-brand mx-auto" href="../index.php"><img src="../img/h202logo.svg" width="50" alt="Logo">H2O2</a>
            </nav>
                        <?php
                            $storeSelect = "SELECT f.*, s.StoreName, s.Logo, s.Website FROM favorites f, store s WHERE f.UserID = $id AND s.StoreID = f.StoreID";
                            $query = mysqli_query($conn, $storeSelect);
                            if(mysqli_num_rows($query) > 0) {
                                while($coupon = mysqli_fetch_array($query)) {
                            ?>
            <div class="card coupon-card mx-auto my-2 shadow">
                <div class="row">
                    <div class="card-body">
                        <a href="<?php echo $coupon["Website"];?>" class="float-right" target="_blank">Visit Site <img src="/img/external-link-symbol.svg" alt="external" height="20" width="20"></a>
                        <img src="<?php echo $coupon["Logo"]; ?>" width="40" class="rounded-pill shadow float-left border mr-2" alt="store-logo">
                        <p class="card-text text-uppercase mx-2 py-2" style="text-shadow:.5px .5px 1.5px black;"><?php echo $coupon["StoreName"]; ?></p>
                            <div class="text-center">
                                    <a href="<?php echo strtolower($coupon["StoreName"]);?>.php">
                                        <button type="button" class="btn btn-success my-2">Store Page</button>
                                    </a>
                                </div>
                        </div>
                    </div>
                </div>
                            <?php 
                            
                        }
                    }
                            ?>
        </div>
        <!-- /#wrapper -->

        <!-- Bootstrap core JavaScript -->
        <script src="vendor/jquery/jquery.min.js"></script>
        <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

        <!-- Menu Toggle Script -->
        <script>
            $("#menu-toggle").click(function(e) {
            e.preventDefault();
            $("#wrapper").toggleClass("toggled");
            });
        </script>   
    </body>
</html>