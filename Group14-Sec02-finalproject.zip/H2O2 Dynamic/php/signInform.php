<?php
session_start();
require("dbdetails.php");
$error='';
if($_SERVER['REQUEST_METHOD']=='POST'){
    if(empty($_POST['email']) || empty($_POST['password'])){
        $error ="Email or password is required";
    } else{
        $email=$_POST['email'];
        $password=$_POST['password'];
        $login1 = "SELECT * FROM users WHERE Email='$email'";
        $result1 = mysqli_query($conn, $login1);
        $row1 = mysqli_fetch_array($result1);
        if (is_array($row1)){
        $hashedPassword = $row1['Password'];
        if (password_verify($password, $hashedPassword)){
            $User_Status=$row1['Account_Status'];
            if($User_Status==1){
            $_SESSION['name']=$row1['Name'];
            $_SESSION['id']=$row1['ID'];
            $id=$row1['ID'];
            header("location:../index.php");
        } else{
            echo "Your account has been disabled";
        }
        } else {
            echo "Login information is invalid";
          }
    } else{
        echo "Login information is invalid";
    }
}
} else {
    echo "you are not authoerized to enter this page";
}

      
?>