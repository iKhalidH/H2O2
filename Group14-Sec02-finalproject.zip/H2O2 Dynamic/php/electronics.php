<?php require 'header.php';?>
<!doctype html>
<html lang="en">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="keywords" content="Coupon, Yousef, Mowfaq, Khalid, H2O2, Offer, deal, shopping, shop">
        <meta name="description" content="A tailormade experience for your shopping leasiure where you may find all kinds of coupons and offers that will fulfill your needs">
        <meta name="author" content="Yousef Taj, Khalid AlAmro, Mowfaq Wale">
        <link rel="icon" href="img/TabIcon.svg">
        
        <!-- Bootstrap & Personal CSS -->
        <link rel="stylesheet" href="/css/bootstrap.min.css">
        <link rel="stylesheet" href="/css/style.css">
        <script src="jquery-3.5.1.min.js"></script>

        <title>H2O2 Coupon - Electronics</title>
    </head>

    <body>
        
        <script src="../js/script.js"></script>
        <div class="container fade-in">
        <div class="row mx-auto justify-content-center py-3">
            <h1 class="display-4 mx-auto align-middle"><img src="../img/desktop.svg" width=100 height=100 alt="Electronics">
                Electronics
            </h1>
        </div>
        <hr>
        
        <!-- This is a sample coupon card. It contains an image, the coupon and a short description -->
              <?php
              require 'dbdetails.php';
        $cat = "SELECT CatID FROM category WHERE Name='Electronics'";
        $result1 = mysqli_query($conn, $cat);
        $row1 = mysqli_fetch_array($result1);
        if (is_array($row1)){
            $CatID=$row1['CatID'];
        }
        $store = "SELECT * FROM store WHERE CatID='$CatID'";
        $result1 = mysqli_query($conn, $cat);
        $row1 = mysqli_fetch_array($result1);
        if (is_array($row1)){
            $CatID=$row1['CatID'];
        }
        $store = "SELECT * FROM store WHERE CatID='$CatID'";
        $result2 = mysqli_query($conn, $store);
        
        echo"<div class='row'>";
        while ($storearray = mysqli_fetch_array($result2)){
            $StoreID=$storearray['StoreID'];
            $coupon = "SELECT * FROM coupon WHERE StoreID='$StoreID' AND End_Date >=curdate()";
        $result3 = mysqli_query($conn, $coupon);
        while ($couponarray = mysqli_fetch_array($result3)){
            echo "<div class='card coupon-card mx-auto my-2 shadow'>";
                echo "<div class='col'>";
                    echo "<div class='card-body'>";
                       echo "<a href='".$storearray['Website']."' class='float-right' target='_blank'>Visit Site <img src='../img/external-link-symbol.svg' alt='external' height='20' width='20'></a>";
                        echo "<img src='".$storearray['Logo']."' width='40' class='rounded-pill shadow float-left border mr-2' alt='store-logo'>";
                        echo "<p class='card-text text-uppercase mx-2 py-2' style='text-shadow:.5px .5px 1.5px black;'>".$storearray['StoreName']."</p>";
                        echo "<span id='c".$couponarray['CouponID']."'; hidden>".$couponarray['Code']."</span>";
                        echo "<h5 class='card-title text-uppercase'>".$couponarray['Code']."</h5>";
                        echo "<p class='card-text'>".$couponarray['Description']."</p>";
                        echo "<p class='card-text'><small class='text-muted'>Expires ".$couponarray['End_Date']."</small></p>";
                        echo "<button class='btn btn-success coupon-copy mr-2 mr-lg-3 mt-3' onclick='copy(c".$couponarray['CouponID'].".id)'>";
                            echo "Copy Coupon";
                        echo "</button>";
                        echo "<div class='picture float-right'>";
                            echo "<a href='electronics.php?type=like&id=".$couponarray['CouponID']."'><img src='../img/like.svg' alt='like coupon' height='20' width='20'></a>";
                            echo "<a href='electronics.php?type=dislike&id=".$couponarray['CouponID']."'><img src='../img/dislike.svg' alt='dislike coupon' height='20' width='20' class = 'ml-5'></a>";
                                                        $Totalquery = "SELECT COUNT(*) FROM coupon_impression WHERE CouponID=".$couponarray['CouponID']."";
                            $Totalresult = mysqli_query($conn, $Totalquery);
                            $row = $Totalresult->fetch_row();
                            $Total=$row[0];
                            $Likes=0;
                            $Percentage=0;
                            $Likesquery = "SELECT COUNT(*) FROM coupon_impression WHERE CouponID='".$couponarray['CouponID']."' AND isLike='1'";
                            $Likesresult = mysqli_query($conn, $Likesquery);
                            $row2 = $Likesresult->fetch_row();
                            $Likes=$row2[0];     
                            if($Total>0){
                            $Percentage=($Likes/$Total)*100;
                            } else{
                            $Percentage=0;
                            }
                            echo "<p class='card-text text-uppercase'>".ceil($Percentage)."% Success</p>";
                        echo "</div>";
                    echo "</div>";

                echo "</div>";

            echo "</div>";

}
        }
        echo "</div>";


                ?>

                

          
               
      </div>
  </div>
</div>
</div>
<?php require 'feedback.php'; ?>
<?php require 'footer.php';?>
  </body>
</html>
