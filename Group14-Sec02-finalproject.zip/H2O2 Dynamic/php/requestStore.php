<?php 
session_start();
         if(!isset($_SESSION['name'])){
echo "You are not authorized to enter this page";
exit;                
  }
  $id=$_SESSION['id'];
?>
<?php require 'dbdetails.php';?>

        
        <!-- Bootstrap & Personal CSS -->
        <link rel="stylesheet" href="/css/bootstrap.min.css">
        <link rel="stylesheet" href="/css/style.css">
<script src="jquery-3.5.1.min.js"></script>

        <title>Profile</title>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="keywords" content="Coupon, Yousef, Mowfaq, Khalid, H2O2, Offer, deal, shopping, shop">
    <meta name="description" content="A tailormade experience for your shopping leasiure where you may find all kinds of coupons and offers that will fulfill your needs">
    <meta name="author" content="Yousef Taj, Khalid AlAmro, Mowfaq Wale">
    <link rel="icon" href="img/TabIcon.svg">
    <title>Request Store</title>
    
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/adminStyle.css">
</head>
<body>

        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
        <script src="tabs.js"></script>
        <!-- JavaScript Search Function -->
        <script src="js/UserSearch.js"></script>
    
        <div class="d-flex" id="wrapper">

        <?php
            require('sidenavuser.php');
        ?>

        <!-- Page Content -->
        <div id="page-content-wrapper">

            <nav class="navbar navbar-expand-lg navbar-light bg-light pb-2 border-bottom">
                <span class="navbar-toggler-icon" id="menu-toggle"></span>

                <a class="navbar-brand mx-auto" href="../index.php"><img src="../img/h202logo.svg" width="50" alt="Logo">H2O2</a>
            </nav>
        <!-- Aligning the row -->
    <div class="container-fluid faid-in">
        <div class="row mt-3 mx-auto d-flex align-items-start d-block">
        
                    <div class="container mx-auto pt-2">
                        <div class="table-responsive rounded-table shadow">
                        <table class="table table-hover" id="tb">
                            <thead class="thead shadow">
                                <th scope="col">Number</th>
                                <th scope="col">Title</th>
                                <th scope="col">Status</th>
                            </thead>
                            <?php
                            $requestSelect = "SELECT * FROM request WHERE Submitter_ID = $id";
                            $query = mysqli_query($conn, $requestSelect);
                            if(mysqli_num_rows($query) > 0) {
                                while($tb = mysqli_fetch_array($query)) {
                            ?>
                        <tbody>
                            <tr>
                                <td><?php echo $tb["ID"]; ?></td>
                                <td><?php echo $tb["Title"]; ?></td>
                                <td>
                                    <?php echo statusCheck($tb["Status"]); ?>
                                </td>
                            </tr>
                            <?php 
                            
                        }
                    }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <hr>
             <button class="btn btn-success mx-auto d-block my-4">
                <a class="text-black-50" href="/php/requestForm.php">Request a new store</a>
            </button>
        </div>
    </div>
    <?php
    function statusCheck($status) {
    if($status == '1') {
        return '<span class="badge badge-success">Accepted</span>';
    }
    else if ($status == '2') {
        return '<span class="badge badge-danger">Rejected</span>';
    }
    else {
        return '<span class="badge badge-info">Ongoing</span>';
    }
}?>
        </div>
        <!-- /#wrapper -->

        <!-- Bootstrap core JavaScript -->
        <script src="vendor/jquery/jquery.min.js"></script>
        <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

        <!-- Menu Toggle Script -->
        <script>
            $("#menu-toggle").click(function(e) {
            e.preventDefault();
            $("#wrapper").toggleClass("toggled");
            });
        </script>   
    </body>
</html>