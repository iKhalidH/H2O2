<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="Coupon, Yousef, Mowfaq, Khalid, H2O2, Offer, deal, shopping, shop">
    <meta name="description"
        content="A tailormade experience for your shopping leasiure where you may find all kinds of coupons and offers that will fulfill your needs">
    <meta name="author" content="Yousef Taj, Khalid AlAmro, Mowfaq Wale">
    <link rel="icon" href="img/TabIcon.svg">

    <!-- Bootstrap & Personal CSS -->
    <link rel="stylesheet" href="/css/bootstrap.min.css">
    <link rel="stylesheet" href="/css/style.css">

    <title>H2O2 Coupon - Request Form</title>
</head>

<body>
    <script src="/js/bootstrap.bundle.min.js"></script>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"
        integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js"
        integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s"
        crossorigin="anonymous"></script>

    <div class="contain mx-auto my-5 w-75">

        <!-- Request store form -->
        <div class="card card-form text-center">
            <div class="card-body">
                <!-- Logo of store. Double as link to index page -->
                <a href="/index.php">
                    <img src="/img/h202logo.svg" height="200" width="200" loading="lazy" alt="H2O2logo">
                </a>
                <!-- Title of card -->
                <h5 class="card-title">Request a new store</h5>

                <!-- Form to enter details and log in -->
                <form action="requestProccess.php" method="POST" class="mt-2">
                    <div class="form-group mx-auto">
                        <label for="Store_name">Store name*</label>
                        <input type="text" placeholder="Noon" class="form-control" id="Store_name"
                            name="Store_name" aria-describedby="Store_name" required>
                    </div>
                    <div class="form-group mx-auto">
                        <label for="Store_website">Store website*</label>
                        <input type="url" placeholder="https://www.noon.com/saudi-en/" class="form-control" id="Store_website"
                            name="Store_website" aria-describedby="Store_website" required>
                    </div>
                    <div class="form-group text-center mx-auto">
                        <label class="d-block" for="Store_reason">Reason</label>
                        <textarea name="text" id="Store_reason" cols="25" rows="5"></textarea>
                    </div>
                    <button type="Submit" name="submit" class="btn btn-primary shadow btn-lg"> Request store</button>
                </form>
            </div>
        </div>
    </div>

    <!-- Additional link to index page -->
    <div class="container mx-auto text-center mb-3">
        <a href="../index.php" class="a-home">Return to Home</a>
    </div>
</body>