<?php 
session_start();
         if(!isset($_SESSION['name'])){
echo "You are not authorized to enter this page";
exit;                
  }
  $id=$_SESSION['id'];
?>
<?php require 'dbdetails.php';?>

        
        <!-- Bootstrap & Personal CSS -->
        <link rel="stylesheet" href="/css/bootstrap.min.css">
        <link rel="stylesheet" href="/css/style.css">
<script src="jquery-3.5.1.min.js"></script>

        <title>Profile</title>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="keywords" content="Coupon, Yousef, Mowfaq, Khalid, H2O2, Offer, deal, shopping, shop">
    <meta name="description" content="A tailormade experience for your shopping leasiure where you may find all kinds of coupons and offers that will fulfill your needs">
    <meta name="author" content="Yousef Taj, Khalid AlAmro, Mowfaq Wale">
    <title>Change name</title>
    
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/adminStyle.css">
</head>
<body>

        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
        <script src="tabs.js"></script>
        <!-- JavaScript Search Function -->
        <script src="js/UserSearch.js"></script>
    
        <div class="d-flex" id="wrapper">


        <!-- Page Content -->
        <div id="page-content-wrapper">

            <nav class="navbar navbar-expand-lg navbar-light bg-light pb-2 border-bottom">
                <span class="navbar-toggler-icon" id="menu-toggle"></span>

                <a class="navbar-brand mx-auto" href="../index.php"><img src="../img/h202logo.svg" width="50" alt="Logo">H2O2 Dashboard</a>
            </nav>
            <?php
            $userNum = mysqli_query($conn,"SELECT COUNT(*) as total1 FROM users");
            $data1=mysqli_fetch_assoc($userNum);
            $adminNum = mysqli_query($conn,"SELECT COUNT(*) as total2 FROM admin");
            $data2=mysqli_fetch_assoc($adminNum);
            $techNum = mysqli_query($conn,"SELECT COUNT(*) as total3 FROM technician");
            $data3=mysqli_fetch_assoc($techNum);
            $storeNum = mysqli_query($conn,"SELECT COUNT(*) as total4 FROM store");
            $data4=mysqli_fetch_assoc($storeNum);
            $catNum = mysqli_query($conn,"SELECT COUNT(*) as total5 FROM category");
            $data5=mysqli_fetch_assoc($catNum);
            $couponNum = mysqli_query($conn,"SELECT COUNT(*) as total6 FROM coupon");
            $data6=mysqli_fetch_assoc($couponNum);
            $requestedNum = mysqli_query($conn,"SELECT COUNT(*) as total7 FROM request");
            $data7=mysqli_fetch_assoc($requestedNum);
                                    ?>
                                    <div class = "mx-auto text-center">
                                    <p>Number of Registered Users: <?php echo $data1['total1']; ?> </p>
                                    <p>Number of Admins: <?php echo $data2['total2']; ?> </p>
                                    <p>Number of Technicians: <?php echo $data3['total3']; ?> </p>
                                    <p>Number of Stores: <?php echo $data4['total4']; ?> </p>
                                    <p>Number of Categories: <?php echo $data5['total5']; ?> </p>
                                    <p>Number of Coupons: <?php echo $data6['total6']; ?> </p>
                                    <p>Number of Requested Stores: <?php echo $data7['total7']; ?> </p>
                                    </div>
        </div>
        <!-- /#wrapper -->

        <!-- Bootstrap core JavaScript -->
        <script src="vendor/jquery/jquery.min.js"></script>
        <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

        <!-- Menu Toggle Script -->
        <script>
            $("#menu-toggle").click(function(e) {
            e.preventDefault();
            $("#wrapper").toggleClass("toggled");
            });
        </script>   
    </body>
</html>