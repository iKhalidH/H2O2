<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="Coupon, Yousef, Mowfaq, Khalid, H2O2, Offer, deal, shopping, shop">
    <meta name="description"
        content="A tailormade experience for your shopping leasiure where you may find all kinds of coupons and offers that will fulfill your needs">
    <meta name="author" content="Yousef Taj, Khalid AlAmro, Mowfaq Wale">
    <link rel="icon" href="img/TabIcon.svg">

    <!-- Bootstrap & Personal CSS -->
    <link rel="stylesheet" href="/css/bootstrap.min.css">
    <link rel="stylesheet" href="/css/style.css">

    <title>H2O2 Coupon - Stores</title>
</head>

<body>
    <script src="/js/bootstrap.bundle.min.js"></script>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"
        integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js"
        integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s"
        crossorigin="anonymous"></script>

    <?php require 'header.php';?>
    <div class="container-fluid fade-in">
        <!-- Aligning the row for each store -->
        <div class="container-fluid">
            <div class="row mt-3 mx-auto d-flex align-items-start">
                <!-- Designing the logo thumbnail for the store and making it responsive -->
                <div class="card shadow mb-3 col-md-9 mx-auto">
                    <div class="row no-gutters">
                        <!-- Logo of the store -->
                        <div class="col-md-4 text-center">
                            <img src="/img/amazon.jpg" class="card-img rounded-circle" alt="amazon-logo">
    
                            <!-- Button for store's coupon page. -->
                            <button class="btn btn-success mx-auto d-block my-4">
                                <a class="text-black-50" href="/php/amazon.php">Store Page</a>
                            </button>
                        </div>
                        <!-- This is the card's body -->
                        <div class="col-md-8">
                            <div class="card-body text-center">
                                <!-- Store name -->
                                <a href="https://www.amazon.com/" class="d-lg-block d-none float-right" target="_blank">Visit Site <img
                                        src="/img/external-link-symbol.svg" alt="external" height="20" width="20"></a>
                                <h2 class="card-text text-uppercase text-center">Amazon</h2>
                                <!-- A link to the website. -->
                                <a href="https://www.amazon.com/" class="d-lg-none" target="_blank">Visit Site <img
                                src="/img/external-link-symbol.svg" alt="external" height="20" width="20"></a>
                                <!-- Store description -->
                                <p class="card-text d-none d-md-block mt-3">Amazon is a website known for its disruption of well-established industries through technological innovation and mass scale. It is the world's largest online marketplace, AI assistant provider, live-streaming platform and cloud computing platform. It is deemed one of the biggest business success stories on the globe. It has “the Earth's Biggest Selection” of products, with categories ranging from electronics, music, and homewares to furniture, personal care, and sporting goods. Amazon has grown to a customer base of more than 30 million people
                                </p>
                                <p><strong>Similar shops</strong></p>
                                <hr>
                                <!-- Making a button for each similar store -->
                                <div class="text-center">
                                    <a href="/php/noon.php">
                                        <button type="button" class="btn btn-secondary my-2">Noon</button>
                                    </a>
                                    <a href="/php/namshi.php">
                                        <button type="button" class="btn btn-secondary my-2">Namshi</button>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    
        <div class="container-fluid">
            <div class="row mt-3 mx-auto d-flex align-items-start">
                <!-- Designing the logo thumbnail for the store and making it responsive -->
                <div class="card shadow mb-3 col-md-9 mx-auto">
                    <div class="row no-gutters">
                        <!-- Logo of the store -->
                        <div class="col-md-4 text-center">
                            <img src="/img/noon-logo-horizontal-yellow.png" class="card-img rounded-circle" alt="noon-logo">
    
                            <!-- Button for store's coupon page. -->
                            <button class="btn btn-success mx-auto d-block my-4">
                                <a class="text-black-50" href="/php/noon.php">Store Page</a>
                            </button>
                        </div>
                        <!-- This is the card's body -->
                        <div class="col-md-8">
                            <div class="card-body text-center">
                                <!-- A link to the website. -->
                                <a href="https://www.noon.com/saudi-en/" class="d-none d-lg-block float-right" target="_blank">Visit Site <img
                                        src="/img/external-link-symbol.svg" alt="external" height="20" width="20"></a>
                                <!-- Store name -->
                                <h2 class="card-text text-uppercase text-center">Noon</h2>
                                <a href="https://www.noon.com/saudi-en/" class="d-lg-none" target="_blank">Visit Site <img
                                        src="/img/external-link-symbol.svg" alt="external" height="20" width="20"></a>
                                <!-- Store description -->
                                <p class="card-text d-none d-md-block mt-3">Noon is the lifestyle shopping destination for the region, by the
                                    region. With the largest online selection of leading brands in categories such as
                                    electronics, fashion, health & beauty, fragrances, grocery, baby products and homeware,
                                    noon is the one stop shopping destination for all your needs. Free shipping! Get
                                    millions of items delivered at your doorstep. Find the products you need with advanced
                                    search, dynamic filters and easy navigation. Easily search and add items to your
                                    shopping cart and wish lists. Convenient choice of payment options: use cash on
                                    delivery, credit and debit cards, Apple Pay and even easy installment options on
                                    checkout. Easy 15 Day return policy for hassle free shopping.
                                </p>
                                <p><strong>Similar shops</strong></p>
                                <hr>
                                <!-- Making a button for each similar store -->
                                <div class="text-center">
                                    <a href="/php/namshi.php">
                                        <button type="button" class="btn btn-secondary my-2">Namshi</button>
                                    </a>
                                    <a href="/php/amazon.php">
                                        <button type="button" class="btn btn-secondary my-2">Amazon</button>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    
        <div class="container-fluid">
            <div class="row mt-3 mx-auto d-flex align-items-start">
                <!-- Designing the logo thumbnail for the store and making it responsive -->
                <div class="card shadow mb-3 col-md-9 mx-auto">
                    <div class="row no-gutters">
                        <!-- Logo of the store -->
                        <div class="col-md-4 text-center">
                            <img src="/img/namshi.png" class="card-img rounded-circle" alt="namshi-logo">
    
                            <!-- Button for store's coupon page. -->
                            <button class="btn btn-success mx-auto d-block my-4">
                                <a class="text-black-50" href="/php/namshi.php">Store Page</a>
                            </button>
                        </div>
                        <!-- This is the card's body -->
                        <div class="col-md-8">
                            <div class="card-body text-center">
                                <!-- A link to the website. -->
                                <a href="https://en-sa.namshi.com/" class="d-lg-block d-none float-right" target="_blank">Visit Site <img
                                        src="/img/external-link-symbol.svg" alt="external" height="20" width="20"></a>
                                <!-- Store name -->
                                <h2 class="card-text text-uppercase text-center">Namshi</h2>
                                <a href="https://en-sa.namshi.com/" class="d-lg-none" target="_blank">Visit Site <img
                                        src="/img/external-link-symbol.svg" alt="external" height="20" width="20"></a>
                                <!-- Store description -->
                                <p class="card-text d-none d-md-block mt-3">Offering the latest trends for men, women and kids, Namshi is your
                                    top choice for online shopping in Saudi Arabia. We've got a growing range of brands
                                    ranging from Nike to Ginger, Puma, adidas, Ella and many others, with new products added
                                    on a regular basis. With a massive range of clothing, shoes, accessories, cosmetics and
                                    fragrances, home and lifestyle products and gifts, we aim to make shopping as easy as
                                    possible with delivery across KSA. Browse our menswear collection to find a full range
                                    of clothes for any and every occasion, from casual to formal. View our women's clothing
                                    selection for the finest online shopping in Saudi Arabia for clothes that suit your
                                    style. Keep your little one looking good with a collection of kids' clothing for all
                                    ages. We've also got a wide range of premium products, a frequently updated fragrance
                                    selection, a beauty shop that stocks the latest cosmetics and everything else you need
                                    to look and feel your best. Whether you're online shopping in Riyadh or online shopping
                                    in Jeddah, Namshi is your go-to for no-fuss shopping online across Saudi Arabia.
                                </p>
                                <p><strong>Similar shops</strong></p>
                                <hr>
                                <!-- Making a button for each similar store -->
                                <div class="text-center">
                                    <a href="/php/noon.php">
                                        <button type="button" class="btn btn-secondary my-2">Noon</button>
                                    </a>
                                    <a href="/php/amazon.php">
                                        <button type="button" class="btn btn-secondary my-2">Amazon</button>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    
    
        <div class="container-fluid">
            <div class="row mt-3 mx-auto d-flex align-items-start">
                <!-- Designing the logo thumbnail for the store and making it responsive -->
                <div class="card shadow mb-3 col-md-9 mx-auto">
                    <div class="row no-gutters">
                        <!-- Logo of the store -->
                        <div class="col-md-4 text-center">
                            <img src="/img/iHerbLogo.png" class="card-img rounded-circle" alt="iHerb logo">
    
                            <!-- Button for store's coupon page. -->
                            <button class="btn btn-success mx-auto d-block my-4">
                                <a class="text-black-50" href="/php/iherb.php">Store Page</a>
                            </button>
                        </div>
                        <!-- This is the card's body -->
                        <div class="col-md-8">
                            <div class="card-body text-center">
                                <!-- A link to the website. -->
                                <a href="https://sa.iherb.com/" class="d-lg-block d-none float-right" target="_blank">Visit Site <img
                                        src="/img/external-link-symbol.svg" alt="external" height="20" width="20"></a>
                                <!-- Store name -->
                                <h2 class="card-text text-uppercase text-center">iHerb</h2>
                                <a href="https://sa.iherb.com/" class="d-lg-none" target="_blank">Visit Site <img
                                        src="/img/external-link-symbol.svg" alt="external" height="20" width="20"></a>
                                <!-- Store description -->
                                <p class="card-text d-none d-md-block mt-3">iHerb is a California-based retailer with more than 30,000 natural products from over 1,200 trusted brands. Since 1996, iHerb has led the pack in the world of wellness, and over time we’ve added products that enhance everyday life, from grocery to health to beauty and self-care. To ensure freshness, iHerb processes all orders from climate-controlled distribution centers, which protect products from such conditions as humidity, heat, and cold. In addition, iHerb’s distribution centers are industry certified by NSF International, earning Good Manufacturing Practices (GMP) certification.
                                </p>
                                <p><strong>Similar shops</strong></p>
                                <hr>
                                <!-- Making a button for each similar store -->
                                <div class="text-center">
                                    <a href="/php/noon.php">
                                        <button type="button" class="btn btn-secondary my-2">Noon</button>
                                    </a>
                                    <a href="/php/amazon.php">
                                        <button type="button" class="btn btn-secondary my-2">Amazon</button>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="container-fluid">
            <div class="row mt-3 mx-auto d-flex align-items-start">
                <!-- Designing the logo thumbnail for the store and making it responsive -->
                <div class="card shadow mb-3 col-md-9 mx-auto">
                    <div class="row no-gutters">
                        <!-- Logo of the store -->
                        <div class="col-md-4 text-center">
                            <img src="/img/domino.jpg" class="card-img rounded-circle" alt="Domino's Pizza logo">
    
                            <!-- Button for store's coupon page. -->
                            <button class="btn btn-success mx-auto d-block my-4">
                                <a class="text-black-50" href="/php/domino.php">Store Page</a>
                            </button>
                        </div>
                        <!-- This is the card's body -->
                        <div class="col-md-8">
                            <div class="card-body text-center">
                                <!-- A link to the website. -->
                                <a href="https://www.dominos.sa/" class="d-lg-block d-none float-right" target="_blank">Visit Site <img
                                        src="/img/external-link-symbol.svg" alt="external" height="20" width="20"></a>
                                <!-- Store name -->
                                <h2 class="card-text text-uppercase text-center">Domino's Pizza</h2>
                                <a href="https://www.dominos.sa/" class="d-lg-none" target="_blank">Visit Site <img
                                        src="/img/external-link-symbol.svg" alt="external" height="20" width="20"></a>
                                <!-- Store description -->
                                <p class="card-text d-none d-md-block mt-3">Domino's Pizza, Inc., branded as Domino's, is an American multinational pizza restaurant chain founded in 1961. The corporation is Delaware domiciled and headquartered at the Domino's Farms Office Park in Ann Arbor, Michigan.
                                </p>
                                <p><strong>Similar shops</strong></p>
                                <hr>
                                <!-- Making a button for each similar store -->
                                <div class="text-center">
                                    <a href="/php/hungerstation.php">
                                        <button type="button" class="btn btn-secondary my-2">HungerStation</button>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    
    <div class="container-fluid">
            <div class="row mt-3 mx-auto d-flex align-items-start">
                <!-- Designing the logo thumbnail for the store and making it responsive -->
                <div class="card shadow mb-3 col-md-9 mx-auto">
                    <div class="row no-gutters">
                        <!-- Logo of the store -->
                        <div class="col-md-4 text-center">
                            <img src="/img/jarir.jpg" class="card-img rounded-circle" alt="Jarir Bookstore logo">
    
                            <!-- Button for store's coupon page. -->
                            <button class="btn btn-success mx-auto d-block my-4">
                                <a class="text-black-50" href="/php/jarir.php">Store Page</a>
                            </button>
                        </div>
                        <!-- This is the card's body -->
                        <div class="col-md-8">
                            <div class="card-body text-center">
                                <!-- A link to the website. -->
                                <a href="https://www.jarir.com/" class="d-lg-block d-none float-right" target="_blank">Visit Site <img
                                        src="/img/external-link-symbol.svg" alt="external" height="20" width="20"></a>
                                <!-- Store name -->
                                <h2 class="card-text text-uppercase text-center">Jarir Bookstore</h2>
                                <a href="https://www.jarir.com/" class="d-lg-none" target="_blank">Visit Site <img
                                        src="/img/external-link-symbol.svg" alt="external" height="20" width="20"></a>
                                <!-- Store description -->
                                <p class="card-text d-none d-md-block mt-3">Jarir Bookstore is a Saudi Arabian establishment founded by Abdulrahman Nasser Al-Agil. In its early years, the bookstore dealt in used books and art sold by expats living in Riyadh, Saudi Arabia. Since then; it has grown to be the largest retailer of books and consumer electronics in Saudi Arabia. 
                                </p>
                                <p><strong>Similar shops</strong></p>
                                <hr>
                                <!-- Making a button for each similar store -->
                                <div class="text-center">
                                    <a href="/php/noon.php">
                                        <button type="button" class="btn btn-secondary my-2">Noon</button>
                                    </a>
                                    <a href="/php/amazon.php">
                                        <button type="button" class="btn btn-secondary my-2">Amazon</button>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
    <div class="container-fluid">
            <div class="row mt-3 mx-auto d-flex align-items-start">
                <!-- Designing the logo thumbnail for the store and making it responsive -->
                <div class="card shadow mb-3 col-md-9 mx-auto">
                    <div class="row no-gutters">
                        <!-- Logo of the store -->
                        <div class="col-md-4 text-center">
                            <img src="/img/saudia.jpg" class="card-img rounded-circle" alt="Saudia Airlines logo">
    
                            <!-- Button for store's coupon page. -->
                            <button class="btn btn-success mx-auto d-block my-4">
                                <a class="text-black-50" href="/php/saudia.php">Store Page</a>
                            </button>
                        </div>
                        <!-- This is the card's body -->
                        <div class="col-md-8">
                            <div class="card-body text-center">
                                <!-- A link to the website. -->
                                <a href="https://www.saudia.com/" class="d-lg-block d-none float-right" target="_blank">Visit Site <img
                                        src="/img/external-link-symbol.svg" alt="external" height="20" width="20"></a>
                                <!-- Store name -->
                                <h2 class="card-text text-uppercase text-center">Saudia Airlines</h2>
                                <a href="https://www.saudia.com/" class="d-lg-none" target="_blank">Visit Site <img
                                        src="/img/external-link-symbol.svg" alt="external" height="20" width="20"></a>
                                <!-- Store description -->
                                <p class="card-text d-none d-md-block mt-3">Saudia, formerly known as Saudi Arabian Airlines, is the flag carrier of Saudi Arabia, based in Jeddah. The airline's main operational base is at King Abdulaziz International Airport in Jeddah. King Khalid International Airport in Riyadh and King Fahd International Airport in Dammam are secondary hubs. 
                                </p>
                                <p><strong>Similar shops</strong></p>
                                <hr>
                                <!-- Making a button for each similar store -->
                                <div class="text-center">
                                    <a href="/php/noon.php">
                                        <button type="button" class="btn btn-secondary my-2">Noon</button>
                                    </a>
                                    <a href="/php/amazon.php">
                                        <button type="button" class="btn btn-secondary my-2">Amazon</button>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    
    <div class="container-fluid">
            <div class="row mt-3 mx-auto d-flex align-items-start">
                <!-- Designing the logo thumbnail for the store and making it responsive -->
                <div class="card shadow mb-3 col-md-9 mx-auto">
                    <div class="row no-gutters">
                        <!-- Logo of the store -->
                        <div class="col-md-4 text-center">
                            <img src="/img/hungerStation.png" class="card-img rounded-circle" alt="HungerStation logo">
    
                            <!-- Button for store's coupon page. -->
                            <button class="btn btn-success mx-auto d-block my-4">
                                <a class="text-black-50" href="/php/hungerstation.php">Store Page</a>
                            </button>
                        </div>
                        <!-- This is the card's body -->
                        <div class="col-md-8">
                            <div class="card-body text-center">
                                <!-- A link to the website. -->
                                <a href="https://hungerstation.com/sa-ar" class="d-lg-block d-none float-right" target="_blank">Visit Site <img
                                        src="/img/external-link-symbol.svg" alt="external" height="20" width="20"></a>
                                <!-- Store name -->
                                <h2 class="card-text text-uppercase text-center">HungerStation</h2>
                                <a href="https://hungerstation.com/sa-ar" class="d-lg-none" target="_blank">Visit Site <img
                                        src="/img/external-link-symbol.svg" alt="external" height="20" width="20"></a>
                                <!-- Store description -->
                                <p class="card-text d-none d-md-block mt-3">The first Saudi Food delivery App in the region! Browse the largest selection of restaurants and supermarkets in your city. The list is updated daily with dozens of internationally established brands and local cuisines restaurants, supermarkets, pharmacies, and flower shops, just pick your favorite and Order Now. With more than 10,000 partners operating in more than 80 cities in Saudi Arabia and Bahrain, HungerStation is the platform to order what you want, while enjoying an easy and fast ordering experience. With HungerStation, you can order from your favorite restaurants, supermarkets, pharmacies, and more! And choose to pay online or cash on delivery, all from the comfort of your home!
                                </p>
                                <p><strong>Similar shops</strong></p>
                                <hr>
                                <!-- Making a button for each similar store -->
                                <div class="text-center">
                                    <a href="/php/domino.php">
                                        <button type="button" class="btn btn-secondary my-2">Domino's Pizza</button>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Footer -->
    <?php require 'footer.php';?>
</body>

</html>