<?php

include '../dbdetails.php';




//Removes Technician
if(isset($_POST["delete"])) {

    $id = $_POST["TechnicianID"];
    $stm = "DELETE FROM technician WHERE TechnicianID = '$id';"; 

    $query = mysqli_query($conn, $stm);
    if($query) {
        header("location: ../technician.php");
    }
    else {
        header("location: ../technician.php?Error");
    }
}