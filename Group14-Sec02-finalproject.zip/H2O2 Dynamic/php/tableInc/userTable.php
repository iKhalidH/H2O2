<input type="text" placeholder="Search username" id="userSearch" onkeyup="UserSearch()">
<!-- Search Function -->
<script src="js/UserSearch.js"></script>
<div class="div" style="margin-bottom: 1em;"> </div>
<table class="table" id="tb">
    <thead class="thead-dark">
        <th>User ID</th>
        <th>Username</th>
        <th>Account Status</th>
        <th>Change Status</th>
        <th>Make Admin</th>
        <th>Make Technician</th>
        <th>Terminate Account</th>
    </thead>
    <?php
    require_once 'includes/dbhandler.php';
    $userSelect = "SELECT * FROM users WHERE ID NOT IN (SELECT * FROM `admin`) and ID NOT IN (SELECT * FROM `technician`)";
    $query = mysqli_query($conn, $userSelect);
    if (mysqli_num_rows($query) > 0) {
        while ($tb = mysqli_fetch_array($query)) {



    ?>
            <tbody>
                <tr>
                    <td><?php echo $tb["ID"]; ?></td>
                    <td><?php echo $tb["Name"]; ?></td>
                    <td><?php
                        if ($tb["Account_Status"] == 0) {
                            echo '<span class="badge badge-danger">Disabled</span>';
                        } else {
                            echo '<span class="badge badge-success">Active</span>';
                        }

                        ?></td>
                    <form action="tableInc/user.process.php" method="POST">
                        <input type="hidden" name="ID" value="<?php echo $tb["ID"]; ?>">
                        <input type="hidden" name="Name" value="<?php echo $tb["Name"]; ?>">
                        <td>
                            <?php
                            if ($tb["Account_Status"] == 0) {
                                echo '<button class="btn btn-secondary" type="submit" name="reactivate">Reactivate</button>';
                            } else {
                                echo '<button class="btn btn-warning" type="submit" name="disable">Disable</button>';
                            }
                            ?>
                        </td>

                        <td>
                            <button class="btn btn-info" type="submit" name="makeAdmin">Make Admin</button>
                        </td>

                        
                        <td>
                            <button class="btn btn-info" type="submit" name="makeTechnician">Make Technician</button>
                        </td>
                        <td>
                            <button class="btn btn-danger" type="submit" name="terminate" onclick="return confirm('Are you sure you wanna continue?');">Terminate</button>
                        </td>
                    </form>
                </tr>
        <?php

        }
    }
        ?>
            </tbody>
</table>
