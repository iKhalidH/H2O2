
        <button class="btn btn-add" data-toggle="modal" data-target = "#addForm">Add Category</button>
        <div class="div" style="margin-bottom: 1em;"> </div>
        <table class="table md-auto" id = "tb">
            <thead class="thead-dark">
                <th>Category ID</th>
                <th>Name</th>
                <th>Category Description</th>
                <th>Edit</th>
                <th>Delete</th>
            </thead>
<?php 
require_once 'includes/dbhandler.php';
$couponSelect = "SELECT * FROM category;";
$query = mysqli_query($conn, $couponSelect);
if(mysqli_num_rows($query) > 0) {
    while($tb = mysqli_fetch_array($query)) {



?>
            <tbody>
                <tr>
                    <td><?php echo $tb["CatID"]; ?></td>
                    <td><?php echo $tb["Name"]; ?></td>
                    <td><?php echo $tb["Category_Desc"]; ?></td>
                    <td>
                        <form action="tableInc/category.editForm.php" method="POST">
                            <input type="hidden" name="CatID" value="<?php echo $tb["CatID"]; ?>">
                            <input type="hidden" name="Name" value="<?php echo $tb["Name"]; ?>">
                            <input type="hidden" name="Category_Desc" value="<?php echo $tb["Category_Desc"]; ?>">
                            <button class="btn btn-success" type="submit" name="edit">Edit</button>
                        </form>
                        
                    </td>
                    <td>
                        <form action="tableInc/category.process.php" method="POST">
                            <input type="hidden" name="CatID" value="<?php echo $tb["CatID"]; ?>">
                            <button class="btn btn-danger" type="submit" name="delete" onclick="return confirm('Are you sure you wanna delete <?php echo 'CategoryID: ' . $tb['CatID']; ?>');">Delete</button>
                        </form>
                        
                    </td>
                </tr>
            <?php 
            
    }
}
            ?>
            </tbody>
        </table>

        
<!-- Modal to add to CouponTable -->
<div class="modal fade" id="addForm" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Add</h5>

            </div>
            <div class="modal-body">
                <form action="tableInc/category.process.php" id="form" method="POST">
                    <input required type="text" name="Name" placeholder="Category Name">
                    <input type="text" name="Category_Desc" placeholder="Category Description">
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" name="categoryAdd" class="btn btn-primary">Add to table</button>
                    </div>
                </form>
            </div>

        </div>

    </div>
