<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit</title>
    <link rel="icon" href="/img/TabIcon.svg">
    
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="/css/adminStyle.css">
</head>
<body> 
    <?php 
    if(isset($_POST["reply"])) {
        $id = $_POST["ID"];
        $title = $_POST["Title"];
        $desc = $_POST["Desc"];
        $address = $_POST["Address"];
    }
    ?>

    <form action="request.form.php" method="POST">
        <div class="form-cont">
            <input type="hidden" name="RequestID" value="<?php echo $id; ?>">
            <h2><strong>Title</strong> </h2>
            <h3><span class="badge badge-success"><?php echo $title ?></span></h3>
            <h2><strong>Reason</strong></h2>
            <p><?php echo $desc; ?></p>
            <h2><strong>Address</strong></h2>
            <p><?php echo $address;?></p>
            <select required name="Status" id="">
                <option value="">Select Status</option>
                <option value="">Ongoing</option>
                <option value="1">Accepted</option>
                <option value="2">Rejected</option>
            </select>
            <button class="btn btn-success" type="submit" name="changeStatus">Done</button>
            <a href="../requestTech.php" class="btn btn-secondary">Go Back</a>
        </div>
    </form>

    <?php 

    ?>


</body>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
</html>

<?php
include '../dbdetails.php';

if(isset($_POST["changeStatus"])) {
    $id = $_POST["RequestID"];
    $status = $_POST["Status"];
    $stm = "UPDATE request SET `Status` = '$status' WHERE ID = '$id';";
    $query = mysqli_query($conn, $stm);
    if($query) {
        header('location: ../requestTech.php');
    }
}
?>
