<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit</title>
    <link rel="icon" href="/img/TabIcon.svg">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="/css/adminStyle.css">
</head>

<body>
    <!-- php page to assign request message to a technician -->
    <?php

    if (isset($_POST["assignBtn"])) {
        $id = $_POST["ID"];
    }
    ?>
    <!-- Form -->
    <form action="request.assignForm.php" method="POST">
        <div class="form-cont">
            <input type="hidden" name="ID" value="<?php echo $id ?>">

            <label for="">Assign Technician</label>
            <select name="TechnicianID" id="">
                <option value="">Select Technician ID</option>
                <?php generateTechID(); ?>
            </select>

            <button name="assign" class="btn btn-primary" type="submit">Assign</button>
        </div>
    </form>

    <?php

    ?>


</body>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>

</html>
<option value=""></option>
<?php

//Generates technician ID from the technician table, if any is available
function generateTechID()
{
    include '../dbdetails.php';
    $selectStm = "SELECT * FROM technician";
    $query = mysqli_query($conn, $selectStm);
    if (mysqli_num_rows($query) > 0) {
        while ($tb = mysqli_fetch_array($query)) {
            echo '<option value="' . $tb["TechnicianID"] . '">' . $tb["TechnicianID"] . '</option>';
        }
    }
}

//Completes the assigning operation
if (isset($_POST["assign"])) {
    include '../dbdetails.php';
    $id = $_POST["ID"];
    $tid = $_POST["TechnicianID"];
    $stm = "UPDATE request SET Technician_ID = '$tid' WHERE ID = '$id';";
    $query = mysqli_query($conn, $stm);
    if ($query) {
        header('location: ../requestAdmin.php');
    }
}
?>