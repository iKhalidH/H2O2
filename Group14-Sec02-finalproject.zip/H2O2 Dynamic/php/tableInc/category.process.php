<?php

require_once '../dbdetails.php';
$error = "";
//Adds into category table
if(isset($_POST["categoryAdd"])) {
    $name = $_POST["Name"];
    $desc = $_POST["Category_Desc"];

    $addStm = "INSERT INTO category VALUES('', '$name','$desc');";
    $addQuery = mysqli_query($conn,$addStm);

    if($addQuery) {
        header("location: ../category.php");
    }
    else {
        header("location: ../category.php?Error");
    }
}

//Edits category table
if(isset($_POST["done"])) {
    $catid = $_POST["CatID"];
    $name = $_POST["Name"];
    $desc = $_POST["Category_Desc"];

    $editStm = "UPDATE category SET `Name`= '$name', Category_Desc = '$desc' WHERE CatID = '$catid';";
    $editQuery = mysqli_query($conn, $editStm);

    if($editQuery) {
        header("location: ../category.php");
    }
    else {
        header("location: ../category.php?Error");
    }
}

//Delete category
if(isset($_POST["delete"])) {
    $catid = $_POST["CatID"];

    $deleteStm = "DELETE FROM category WHERE CatID = '$catid';";

    $delQuery = mysqli_query($conn, $deleteStm);
    if($delQuery) {
        header("location: ../category.php");
    }
    else {
        header("location: ../category.php?Error");
    }
}