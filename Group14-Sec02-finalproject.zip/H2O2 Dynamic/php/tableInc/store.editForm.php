<?php 

//Edits store table
if(isset($_POST["done"])) {
    require_once '../dbdetails.php';
    $sid = $_POST["StoreID"];
    $sname = $_POST["StoreName"];
    $logo = $_POST["Logo"];
    $cid = $_POST["CatID"];
    $website = $_POST["Website"];

    $editStm = "UPDATE store SET StoreName = '$sname', Logo = '$logo', CatID = '$cid', Website = '$website' WHERE StoreID = '$sid';";

    $query = mysqli_query($conn, $editStm);
    if($query) {
        header("location: ../storeAdmin.php");
    }
    else {
        header("location: ../storeAdmin.php?Error");
    }
}

//Generates list of category from the category table
function generateCategorySelect($cid) {
    include '../dbdetails.php';
    $storestm = "SELECT * FROM category;";
    $catQuery = mysqli_query($conn, $storestm);
    $storestm = "SELECT * FROM category;";
    $catQuery = mysqli_query($conn, $storestm);
    
    while ($stbl = mysqli_fetch_array($catQuery)) {
        if($stbl["CatID"] !== $cid)
        echo '<option value="' . $stbl["CatID"] . '">' . $stbl["Name"] . '</option>';
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit</title>
    <link rel="icon" href="/img/TabIcon.svg">
    
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="/css/adminStyle.css">
</head>
<body> 
    <?php 
    if(isset($_POST["edit"])) {
        $sid = $_POST["StoreID"];
        $sname=  $_POST["StoreName"];
        $logo =  $_POST["Logo"];
        $cid =  $_POST["CatID"];
        $website =  $_POST["Website"];
        $cname = $_POST["Name"];
    }
    ?>

    <form action="store.editForm.php" method="POST">
        <div class="form-cont">

            <input type="hidden" name="StoreID" value="<?php echo $sid; ?>">
            <div class="id">StoreID: <?php echo $sid; ?></div><br>

            <label for=""><strong>Store Name</strong></label>
            <input required type="text" name="StoreName" value="<?php echo $sname; ?>" class="form-control">

            <label for=""><strong>Logo Link</strong></label>
            <input type="text" name="Logo" value="<?php echo $logo; ?>">

            <label for="">Select Category</label>
            <select name="CatID" id="">
                <option value="<?php echo $cid ?>"><?php echo $cname; ?></option>
                <?php generateCategorySelect($cid); ?>
            </select>
            <br>
            <label for="">Website</label>
            <input type="text" name="Website" value="<?php echo $website; ?>">
            

            <button class="btn btn-primary" type="submit" name="done">Edit</button>
        </div>
    </form>

    <?php 

    ?>


</body>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
</html>