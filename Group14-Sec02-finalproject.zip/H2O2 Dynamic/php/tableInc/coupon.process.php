<?php

require_once '../dbdetails.php';

//Adds to the coupon table
if(isset($_POST["couponAdd"])) {
    $date=  $_POST["End_Date"];
    $desc =  $_POST["Description"];
    $key =  $_POST["Keyword"];
    $store =  $_POST["StoreID"];
    $code =  $_POST["Code"];

    $addStm = "INSERT INTO coupon VALUES('$date','$desc','$key','$store','$code');";
    $addQuery = mysqli_query($conn, $addStm);
    if($addQuery) {
        header("location: ../couponAdmin.php");
    }
    else {
        header("location: ../couponAdmin.php?Error");
    }
}


//Deletes the table
if(isset($_POST["delete"])) {
    $id = $_POST["CouponID"];
    echo $id;
    $deletestm = "DELETE FROM coupon WHERE CouponID = $id";
    $deletequery = mysqli_query($conn, $deletestm);
    if($deletequery) {
        header("location: ../couponAdmin.php");
    }
    else {
        header("location: ../couponAdmin.php?Error");
    }
}


//Edits the table
if(isset($_POST["done"])) {
    require_once "../dbdetails.php";
    $cid = $_POST["CouponID"];
    $date=  $_POST["End_Date"];
    $desc =  $_POST["Description"];
    $key =  $_POST["Keyword"];
    $store =  $_POST["StoreID"];
    $code =  $_POST["Code"];
   
    $editstm = "UPDATE coupon SET End_Date = '$date', `Description` = '$desc', Keyword = '$key', StoreID = '$store', code = '$code' WHERE CouponID = $cid;";
    $updateQuery = mysqli_query($conn, $editstm);
    if($updateQuery) {
        header("location: ../couponAdmin.php");
    }
    else {
        header("location: ../couponAdmin.php?Error");
    }
}
