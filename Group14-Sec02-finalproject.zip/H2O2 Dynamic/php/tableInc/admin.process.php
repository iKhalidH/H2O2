<?php

include '../dbdetails.php';



//Removes Technician
if(isset($_POST["delete"])) {

    $id = $_POST["AdminID"];
    $stm = "DELETE FROM `admin` WHERE AdminID = '$id';"; 

    $query = mysqli_query($conn, $stm);
    if($query) {
        header("location: ../adminList.php");
    }
    else {
        header("location: ../adminList.php?Error");
    }
}