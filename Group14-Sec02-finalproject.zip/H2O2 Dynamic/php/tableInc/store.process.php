<?php
include '../errorhandler.php';
require_once '../dbdetails.php';

//Adds into store table
if(isset($_POST["storeAdd"])) {
    $sname = $_POST["StoreName"];
    $logo = $_POST["Logo"];
    $catid = $_POST["CatID"];
    $web = $_POST["Website"];

    $addStm = "INSERT INTO store VALUES('$sname','$logo','$catid','$web')";
    $addQuery = mysqli_query($conn, $addStm);
    if($addQuery){
        header('location: ../store.php');
    }
    else {
        header("location: ../store.php?Error");
    }
}

//Edits store table
if(isset($_POST["done"])) {
    $sid = $_POST["StoreID"];
    $sname = $_POST["StoreName"];
    $logo = $_POST["Logo"];
    $cid = $_POST["CatID"];
    $website = $_POST["Website"];

    $editStm = "UPDATE store SET StoreName = '$sname', Logo = '$logo', CatID = '$cid', Website = '$website' WHERE StoreID = '$sid';";

    $query = mysqli_query($conn, $editStm);
    if($query) {
        header("location: ../store.php");
    }
    else {
        header("location: ../store.php?Error");
    }
}

//Deletes from store table
if(isset($_POST["delete"])) {
    require_once '../dbdetails.php';
    $sid = $_POST["StoreID"];
    $deletestm = "DELETE FROM store WHERE StoreID = '$sid';";
    
    $delQuery = mysqli_query($conn, $deletestm);
    if($delQuery) {
        header("location: ../store.php");
    }
    else {
        header("location: ../store.php?Error");  
    }
    
}