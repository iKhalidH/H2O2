        <div class="div" style="margin-bottom: 1em;"> </div>
        <table class="table" id = "tb">
            <thead class="thead-dark">
                <th>Submitter User ID</th>
                <th>Title</th>
                <th>Reason</th>
                <th>Address</th>
                <th>Status</th>
                <th>Reply</th>
            </thead>
<?php 
require_once 'includes/dbhandler.php';
$requestSelect = "SELECT * FROM request";
$query = mysqli_query($conn, $requestSelect);
if(mysqli_num_rows($query) > 0) {
    while($tb = mysqli_fetch_array($query)) {



?>
            <tbody>
                <tr>
                    <td><?php echo $tb["Submitter_ID"]; ?></td>
                    <td><?php echo $tb["Title"]; ?></td>
                    <td><?php echo $tb["Request_Desc"]; ?></td>
                    <td><?php echo $tb["Address"]; ?></td>
                    <td>
                        <?php echo statusCheck($tb["Status"]); ?>
                    </td>
                    <td>
                        <form action="tableInc/request.form.php" method="POST">
                            <input type="hidden" name = "RequestID" value="<?php echo $tb["RequestID"];?>">
                            <input type="hidden" name = "Title" value="<?php echo $tb["Title"];?>">
                            <input type="hidden" name = "Desc" value="<?php echo $tb["Request_Desc"];?>">
                            <input type="hidden" name = "Address" value="<?php echo $tb["Address"];?>">
                            <button type="submit" name="reply" class="btn btn-info">Reply</button>
                        </form>
                    </td>
                </tr>
            <?php 
            
    }
}
            ?>
            </tbody>
        </table>
<?php
function statusCheck($status) {
    if($status == 'accepted') {
        return '<span class="badge badge-success">Accepted</span>';
    }
    else if ($status == 'rejected') {
        return '<span class="badge badge-danger">Rejected</span>';
    }
    else {
        return '<span class="badge badge-info">Ongoing</span>';
    }
}
?>
</form>