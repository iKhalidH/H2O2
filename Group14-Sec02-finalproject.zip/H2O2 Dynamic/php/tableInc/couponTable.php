<input type="text" placeholder="Search by CouponID" id="idsearch" onkeyup="IDSearch()">
<input type="text" placeholder="Search by Keyword" id="keysearch" onkeyup="KeySearch()">
<input type="text" placeholder="Search by Store Name" id="storeIDsrch" onkeyup="StoreSearch()">
<button class="btn btn-add" data-toggle="modal" data-target="#addForm">Add Coupon</button>
<table class="table" id="tb">
    <thead class="thead-dark">
        <th>CouponID</th>
        <th>End_Date</th>
        <th>Description</th>
        <th>Keyword</th>
        <th>Store Name</th>
        <th>Code</th>
        <th>Edit</th>
        <th>Delete</th>
    </thead>
    <?php
    require_once 'includes/dbhandler.php';
    $couponSelect = "SELECT c.*, s.StoreName FROM coupon c, store s WHERE c.StoreID = s.StoreID ORDER BY c.CouponID;";
    $query = mysqli_query($conn, $couponSelect);
    if (mysqli_num_rows($query) > 0) {
        while ($tb = mysqli_fetch_array($query)) {



    ?>
            <tbody>
                <tr>
                    <td><?php echo $tb["CouponID"]; ?></td>
                    <td><?php echo $tb["End_Date"]; ?></td>
                    <td><?php echo $tb["Description"]; ?></td>
                    <td><?php echo $tb["Keyword"]; ?></td>
                    <td><?php echo $tb["StoreName"]; ?></td>
                    <td><?php echo $tb["Code"]; ?></td>
                    <td>
                        <form action="tableInc/coupon.editForm.php" method="POST">
                            <input type="hidden" name="CouponID" value="<?php echo $tb["CouponID"]; ?>">
                            <input type="hidden" name="StoreName" value="<?php echo $tb["StoreName"]; ?>">
                            <input type="hidden" name="End_Date" value="<?php echo $tb["End_Date"]; ?>">
                            <input type="hidden" name="Description" value="<?php echo $tb["Description"]; ?>">
                            <input type="hidden" name="Keyword" value="<?php echo $tb["Keyword"]; ?>">
                            <input type="hidden" name="StoreID" value="<?php echo $tb["StoreID"]; ?>">
                            <input type="hidden" name="Code" value="<?php echo $tb["Code"]; ?>">
                            <button class="btn btn-success" type="submit" name="edit">Edit</button>
                        </form>

                    </td>
                    <td>
                        <form action="tableInc/coupon.process.php" method="POST">
                            <input type="hidden" name="CouponID" value="<?php echo $tb["CouponID"]; ?>">
                            <button type="submit" class="btn btn-danger" name = "delete"  onclick="return confirm('Are you sure you wanna delete <?php echo 'CouponID: ' . $tb['CouponID']; ?>');">Delete</button>
                        </form>
                        </td>
                </tr>
        <?php

        }
    }
        ?>
            </tbody>
</table>


<!-- Search Function -->
<script src="js/SearchFunctions.js"></script>

<!-- Modal to add to CouponTable -->
<div class="modal fade" id="addForm" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Add</h5>

            </div>
            <div class="modal-body">
                <form action="tableInc/coupon.process.php" id="form" method="POST">
                    <input required type="date" name="End_Date" id="end">
                    <input type="text" name="Description" placeholder="Description">
                    <input type="text" name="Keyword" placeholder="Keyword">
                    <select required name="StoreID" id="">
                        <option value="">Select Store</option>
                        <?php
                        include 'includes/dbhandler.php';
                        $storestm = "SELECT * FROM store;";
                        $storeQuery = mysqli_query($conn, $storestm);

                        while ($stbl = mysqli_fetch_array($storeQuery)) {
                            echo '<option value="' . $stbl["StoreID"] . '">' . $stbl["StoreName"] . '</option>';
                        }
                        ?>
                    </select>
                    <input required  type="text" name="Code" placeholder="Code">
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" name="couponAdd" class="btn btn-primary">Add to table</button>
                    </div>
                </form>
            </div>

        </div>

    </div>