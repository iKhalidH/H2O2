
        <button class="btn btn-add" data-toggle="modal" data-target = "#addForm">Add Store</button>
        <div class="div" style="margin-bottom: 1em;"> </div>
        <table class="table" id = "tb">
            <thead class="thead-dark">
                <th>Store ID</th>
                <th>Store Name</th>

                <th>Category</th>
                <th>Website</th>
                <th>Edit</th>
                <th>Delete</th>
            </thead>
<?php 
require_once 'includes/dbhandler.php';
$storeSelect = "SELECT s.*, c.Name FROM store s, category c WHERE s.CatID = c.CatID";
$query = mysqli_query($conn, $storeSelect);
if(mysqli_num_rows($query) > 0) {
    while($tb = mysqli_fetch_array($query)) {



?>
            <tbody>
                <tr>
                    <td><?php echo $tb["StoreID"]; ?></td>
                    <td><?php echo $tb["StoreName"]; ?></td>
                    <td><?php echo $tb["Name"]; ?></td>
                    <td><?php echo $tb["Website"]; ?></td>
                    <td>
                        <form action="tableInc/store.editForm.php" method="POST">
                            <input type="hidden" name="StoreID" value="<?php echo $tb["StoreID"]; ?>">
                            <input type="hidden" name="StoreName" value="<?php echo $tb["StoreName"]; ?>">
                            <input type="hidden" name="Logo" value="<?php echo $tb["Logo"]; ?>">
                            <input type="hidden" name="CatID" value="<?php echo $tb["CatID"]; ?>">
                            <input type="hidden" name="Name" value="<?php echo $tb ["Name"];?>">
                            <input type="hidden" name="Website" value="<?php echo $tb["Website"]; ?>">
                            <button class="btn btn-success" type="submit" name="edit">Edit</button>
                        </form>
                        
                    </td>
                    <td>
                        <form action="tableInc/store.process.php" method="POST">
                            <input type="hidden" name="StoreID" value="<?php echo $tb["StoreID"]; ?>">
                            <button class="btn btn-danger" type="submit" name="delete" onclick="return confirm('Are you sure you wanna continue?');">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php 
            
    }
}
            ?>
            </tbody>
        </table>

        
<!-- Modal to add to CouponTable -->
<div class="modal fade" id="addForm" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Add</h5>

            </div>
            <div class="modal-body">
                <form action="tableInc/store.process.php" id="form" method="POST">
                    <input required type="text" name="StoreName" placeholder="Store Name">
                    <input type="text" name="Logo" placeholder="Logo">
                    <select required name="CatID" id="">
                        <option value="">Select Category</option>
                        <?php
                        include 'includes/dbhandler.php';
                        $storestm = "SELECT * FROM category;";
                        $catQuery = mysqli_query($conn, $storestm);

                        while ($stbl = mysqli_fetch_array($catQuery)) {
                            echo '<option value="' . $stbl["CatID"] . '">' . $stbl["Name"] . '</option>';
                        }
                        ?>
                    </select>
                    <input type="text" name="Website" placeholder="Store Website">
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" name="storeAdd" class="btn btn-primary">Add to table</button>
                    </div>
                </form>
            </div>

        </div>

    </div>
