
        <input type="text" placeholder="Search username" id="userSearch" onkeyup="UserSearch()">
        <!-- Search Function -->
        <script src="js/UserSearch.js"></script>
        <div class="div" style="margin-bottom: 1em;"> </div>
        <table class="table" id = "tb">
            <thead class="thead-dark">
                <th>Technician ID</th>
                <th>Username</th>
                <th>Email</th>
                <th>Account Status</th>
                <th>Remove Technician</th>
            </thead>
<?php 
require_once 'includes/dbhandler.php';
$userSelect = "SELECT t.TechnicianID, u.Name, u.Email, u.Account_Status FROM technician t, users u WHERE t.TechnicianID = u.ID";
$query = mysqli_query($conn, $userSelect);
if(mysqli_num_rows($query) > 0) {
    while($tb = mysqli_fetch_array($query)) {



?>
            <tbody>
                <tr>
                    <td><?php echo $tb["TechnicianID"]; ?></td>
                    <td><?php echo $tb["Name"]; ?></td>
                    <td><?php echo $tb["Email"]; ?></td>
                    <td><?php echo $tb["Account_Status"]; ?></td>
                    <td>
                        <form action="tableInc/tech.process.php" method="POST">
                            <input type="hidden" name="TechnicianID" value="<?php echo $tb["TechnicianID"]; ?>">
                            <button class="btn btn-danger" type="submit" name="delete" onclick="return confirm('Are you sure you wanna continue?');">Remove</button>
                        </form>
                    </td>
                </tr>
            <?php 
            
    }
}
            ?>
            </tbody>
        </table>
