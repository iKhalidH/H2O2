<?php

include '../dbdetails.php';

//disable
if(isset($_POST["disable"])) {

    $id = $_POST["ID"];
    $stm = "UPDATE users SET Account_Status = 0 WHERE ID = '$id';"; 

    $query = mysqli_query($conn, $stm);
    if($query) {
        header("location: ../users.php");
    }
    else {
        header("location: ../users.php?Error");
    }
}

if(isset($_POST["reactivate"])) {

    $id = $_POST["ID"];
    $stm = "UPDATE users SET Account_Status = 1 WHERE ID = '$id';"; 

    $query = mysqli_query($conn, $stm);
    if($query) {
        header("location: ../users.php");
    }
    else {
        header("location: ../users.php?Error");
    }
}

if(isset($_POST["makeAdmin"])) {

    $id = $_POST["ID"];
    $name = $_POST["Name"];
    $stm = "INSERT INTO `admin` VALUES('$id');"; 

    $query = mysqli_query($conn, $stm);
    if($query) {
        header("location: ../users.php?");
    }
    else {
        header("location: ../users.php?AlreadyAdmin");
    }
}

if(isset($_POST["makeTechnician"])) {

    $id = $_POST["ID"];

    $stm = "INSERT INTO technician VALUES('$id');"; 

    $query = mysqli_query($conn, $stm);
    if($query) {
        header("location: ../users.php?");
    }
    else {
        header("location: ../users.php?AlreadyTechnician");
    }
}

if(isset($_POST["terminate"])) {
    $id = $_POST["ID"];
    $stm = "DELETE FROM users WHERE ID = '$id';";
    $query = mysqli_query($conn, $stm);
    if($query) {
        header("location: ../users.php?");
    }
    else {
        header("location: ../users.php?TerminateError");
    }
}