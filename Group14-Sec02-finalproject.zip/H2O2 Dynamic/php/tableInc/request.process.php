<?php

include '../includes/dbhandler.php';



//Removes request
if(isset($_POST["delete"])) {

    $id = $_POST["ID"];
    $stm = "DELETE FROM request WHERE ID = '$id';"; 

    $query = mysqli_query($conn, $stm);
    if($query) {
        header("location: ../requestTech.php");
    }
}