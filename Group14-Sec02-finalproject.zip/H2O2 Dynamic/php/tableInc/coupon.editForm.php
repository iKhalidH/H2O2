<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit</title>
    <link rel="icon" href="/img/TabIcon.svg">
    
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="/css/adminStyle.css">
</head>
<body> 
    <?php 
    //If the edit button was clicked
    if(isset($_POST["edit"])) {
        $cid = $_POST["CouponID"];
        $date=  $_POST["End_Date"];
        $desc =  $_POST["Description"];
        $key =  $_POST["Keyword"];
        $store =  $_POST["StoreID"];
        $code =  $_POST["Code"];
        $storeName = $_POST["StoreName"];
    }
    ?>

    <form action="coupon.editForm.php" method="POST">
        <div class="form-cont">
            <input type="hidden" name="CouponID" value="<?php echo $cid; ?>">
            <div class="id">CouponID: <?php echo $cid; ?></div><br>
            <label for=""><strong>Date</strong></label>
            <input required type="date" name="End_Date" value="<?php echo $date; ?>" class="form-control">
            <label for=""><strong>Description</strong></label>

            <textarea name="Description" id="" cols="25" rows="5"><?php echo $desc; ?></textarea>
            <label for=""><strong>Keyword</strong></label>
            <input type="text" name="Keyword" value="<?php echo $key; ?>" class="form-control">
            <label for=""><strong>Store</strong></label> <br>
            <select required name="StoreID" id="">
                        <option value="<?php echo $store; ?>"><?php echo $storeName; ?></option>
                        <?php
                        include '../includes/dbhandler.php';
                        $storestm = "SELECT * FROM store;";
                        $storeQuery = mysqli_query($conn, $storestm);
                        //Generates list of stores with while loop
                        while ($stbl = mysqli_fetch_array($storeQuery)) {
                            if($stbl["StoreID"] !== $store ) {
                            echo '<option value="' . $stbl["StoreID"] . '">' . $stbl["StoreName"] . '</option>';
                            }
                        }
                        ?>
                    </select>
            <br>
            <label for=""><strong>Code</strong></label>
            <input required type="text" name="Code" value="<?php echo $code ?>" class="form-control">
            <button class="btn btn-primary" type="submit" name="done">Edit</button>
        </div>
    </form>

    <?php
    //Edits the table
    if(isset($_POST["done"])) {
    require_once "../includes/dbhandler.php";
    $cid = $_POST["CouponID"];
    $date=  $_POST["End_Date"];
    $desc =  $_POST["Description"];
    $key =  $_POST["Keyword"];
    $store =  $_POST["StoreID"];
    $code =  $_POST["Code"];
   
    $editstm = "UPDATE coupon SET End_Date = '$date', `Description` = '$desc', Keyword = '$key', StoreID = '$store', code = '$code' WHERE CouponID = $cid;";
    $updateQuery = mysqli_query($conn, $editstm);
    if($updateQuery) {
        header("location: ../couponAdmin.php");
    }
    else {
        echo "<script type='text/javascript'>alert(\"Failed to commit change\");</script>";
        die();
    }
}
    ?>


</body>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
</html>