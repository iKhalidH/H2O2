
        <input type="text" placeholder="Search username" id="userSearch" onkeyup="search()">
        <!-- Search Function -->
        <script src="/js/SearchFunctions.js"></script>
        <div class="div" style="margin-bottom: 1em;"> </div>
        <table class="table" id = "tb">
            <thead class="thead-dark">
                <th>Admin ID</th>
                <th>Username</th>
                <th>Email</th>
                <th>Account Status</th>
                <th>Remove Admin</th>
            </thead>
<?php 
require_once '../dbdetails.php';
$userSelect = "SELECT a.AdminID, u.Name, u.Email, u.Account_Status FROM `admin` a, users u WHERE a.AdminID = u.ID";
$query = mysqli_query($conn, $userSelect);
if(mysqli_num_rows($query) > 0) {
    while($tb = mysqli_fetch_array($query)) {



?>
            <tbody>
                <tr>
                    <td><?php echo $tb["AdminID"]; ?></td>
                    <td><?php echo $tb["Name"]; ?></td>
                    <td><?php echo $tb["Email"]; ?></td>
                    <td><?php echo $tb["Account_Status"]; ?></td>
                    <td>
                        <form action="tableInc/admin.process.php" method="POST">
                            <input type="hidden" name="AdminID" value="<?php echo $tb["AdminID"]; ?>">
                            <button class="btn btn-danger" type="submit" name="delete" onclick="return confirm('Are you sure you want to continue?');">Remove Admin</button>
                        </form>
                    </td>
                </tr>
            <?php 
            
    }
}
            ?>
            </tbody>
        </table>
