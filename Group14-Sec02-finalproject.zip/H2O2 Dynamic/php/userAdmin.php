<?php

if (isset($_POST["disable"])) {
    require_once 'dbdetails.php';
    $id = $_POST["ID"];
    $stm = "UPDATE users SET Account_Status = 0 WHERE ID = '$id';";

    $query = mysqli_query($conn, $stm);
    if ($query) {
        header("location: userAdmin.php");
    }
}

if (isset($_POST["reactivate"])) {
    require_once 'dbdetails.php';
    $id = $_POST["ID"];
    $stm = "UPDATE users SET Account_Status = 1 WHERE ID = '$id';";

    $query = mysqli_query($conn, $stm);
    if ($query) {
        header("location: userAdmin.php");
    }
}

if (isset($_POST["makeAdmin"])) {
    require_once 'dbdetails.php';
    $id = $_POST["ID"];
    $name = $_POST["Name"];
    $stm = "INSERT INTO `admin` VALUES('$id');";

    $query = mysqli_query($conn, $stm);
    if ($query) {
        header("location: userAdmin.php?");
    }
}

if (isset($_POST["makeTechnician"])) {
    require_once 'dbdetails.php';
    $id = $_POST["ID"];

    $stm = "INSERT INTO technician VALUES('$id');";

    $query = mysqli_query($conn, $stm);
    if ($query) {
        header("location: userAdmin.php?");
    }
}

if (isset($_POST["terminate"])) {
    require_once 'dbdetails.php';
    $id = $_POST["ID"];
    $stm = "DELETE FROM users WHERE ID = '$id';";
    $query = mysqli_query($conn, $stm);
    if ($query) {
        header("location: userAdmin.php?");
    }
}

?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ADMIN PANEL</title>
    <link rel="icon" href="/img/TabIcon.svg">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="/css/adminStyle.css">
</head>
<body>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    <script src="tabs.js"></script>
    <!-- JavaScript Search Function -->
    <script src="/js/SearchFunctions.js"></script>
   
    <div class="d-flex" id="wrapper">

    <?php
        require('sidenavAdmin.php');
    ?>

    <!-- Page Content -->
    <div id="page-content-wrapper">

        <nav class="navbar navbar-expand-lg navbar-light bg-light pb-2 border-bottom">
            <span class="navbar-toggler-icon" id="menu-toggle"></span>

            <a class="navbar-brand mx-auto" href=""><img src="/img/h202logo.svg" width="50" alt="Logo">H2O2 Dashboard</a>
        </nav>
        
        <nav class="navbar navbar-expand-lg align-content-center">
            <form class="form-inline w-100 mx-auto my-2 my-lg-0">
                <div class="input-group mt-2 mx-auto w-75">
                <input class="form-control mx-auto"type="search" placeholder="Search Users" id="couponSearch" onkeyup="search()">
                    <select class="nav-item dropdown mx-auto" name="searchOption" id="couponSearchOpt">
                        <option value="0">ID</option>
                        <option value="1">Name</option>
                    </select>
                </div>
            </form>
        </nav>

        <div class="container mx-auto pb-4 pt-2">  

            <div class="container mx-auto pt-2">
                <div class="table-responsive rounded-table shadow">
                    <table class="table table-hover" id="tb">
                        <thead class="thead text-light shadow">
                            <tr>
                                <th scope="col">User ID</th>
                                <th scope="col">Username</th>
                                <th scope="col">Account Status</th>
                                <th scope="col">Change Status</th>
                                <th scope="col">Make Admin</th>
                                <th scope="col">Make Technician</th>
                                <th scope="col">Terminate Account</th>
                            </tr>
                        </thead>
                        
                        <?php
        require_once 'dbdetails.php';
        $userSelect = "SELECT * FROM users WHERE ID NOT IN (SELECT * FROM `admin`) and ID NOT IN (SELECT * FROM `technician`)";
        $query = mysqli_query($conn, $userSelect);
        if (mysqli_num_rows($query) > 0) {
            while ($tb = mysqli_fetch_array($query)) {



        ?>
                <tbody>
                    <tr>
                        <td><?php echo $tb["ID"]; ?></td>
                        <td><?php echo $tb["Name"]; ?></td>
                        <td><?php
                            if ($tb["Account_Status"] == 0) {
                                echo '<span class="text-danger text-uppercase">Disabled</span>';
                            } else {
                                echo '<span class="text-success text-uppercase">Active</span>';
                            }

                            ?></td>
                        <form action="userAdmin.php" method="POST">
                            <input type="hidden" name="ID" value="<?php echo $tb["ID"]; ?>">
                            <input type="hidden" name="Name" value="<?php echo $tb["Name"]; ?>">
                            <td>
                                <?php
                                if ($tb["Account_Status"] == 0) {
                                    echo '<button class="btn btn-secondary" type="submit" name="reactivate">Activate</button>';
                                } else {
                                    echo '<button class="btn btn-warning" type="submit" name="disable">Disable</button>';
                                }
                                ?>
                            </td>

                            <td>
                                <button class="btn btn-info" type="submit" name="makeAdmin">Make Admin</button>
                            </td>


                            <td>
                                <button class="btn btn-info" type="submit" name="makeTechnician">Make Technician</button>
                            </td>
                            <td>
                                <button class="btn btn-edit" type="submit" name="terminate" onclick="return confirm('Are you sure you want to continue?');"><img src="/img/remove.svg" cl width="20" alt=""></button>
                            </td>
                        </form>
                    </tr>
            <?php

            }
        }
            ?>
                </tbody>
                    </table>
                </div>
            </div>

                </div>
                <!-- /#page-content-wrapper -->

            </div>
        <!-- /#wrapper -->

        <!-- Bootstrap core JavaScript -->
        <script src="vendor/jquery/jquery.min.js"></script>
        <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

        <!-- Menu Toggle Script -->
        <script>
            $("#menu-toggle").click(function(e) {
            e.preventDefault();
            $("#wrapper").toggleClass("toggled");
            });
        </script>   
    </body>
    <!-- Search Function -->
    <script src="js/UserSearch.js"></script>    
       
</body>
</html>