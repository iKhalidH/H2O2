<?php require 'header.php';?>
<!doctype html>
<html lang="en">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="keywords" content="Coupon, Yousef, Mowfaq, Khalid, H2O2, Offer, deal, shopping, shop">
        <meta name="description" content="A tailormade experience for your shopping leasiure where you may find all kinds of coupons and offers that will fulfill your needs">
        <meta name="author" content="Yousef Taj, Khalid AlAmro, Mowfaq Wale">
        <link rel="icon" href="img/TabIcon.svg">
        
        <title>H2O2 Coupon - Domino's Pizza</title>
    </head>

    <body>
        <div class="container-fluid fade-in">
        <!-- Aligning the row for the image and the two cards -->
        <div class="row mt-3 mx-auto d-flex align-items-start">
        <!-- Designing the logo thumbnail for the store and making it responsive -->
        <div class="col-md-2 text-center">
            <img src="../img/domino.jpg" alt="Domino's logo" class="rounded-circle img-thumbnail">
            <?php 
            include 'dbdetails.php';
            if (isset($_SESSION['id'])) {
            $id = $_SESSION['id'];
            $selectStm = "SELECT f.* FROM favorites f WHERE f.UserID = $id AND f.StoreID = '6'";
            $query = mysqli_query($conn, $selectStm);
            if ($coupon = mysqli_fetch_array($query)) {
            ?>
            <form action="domino.php" method="post">
               <button type="submit" class="btn btn-danger mt-5" name ="removeFav">Remove From Favourites</button> 
            </form>
            <?php 
            } else {
            ?>
            <form action="domino.php" method="post">
            <button type="submit" class="btn btn-success mt-5" name = "addFav">Add To Favourites</button>
            </form>
        <?php 
            }
            }
            ?>
        </div>
        <div class="col-md-10 my-5">
            <p class="text-center">Similar Shops</p>
            <hr>
            <!-- Making a button for each similar store -->
            <div class="text-center">
                <a href="hungerstation.php" type="button" class="btn btn-secondary my-2">
                    HungerStation
                </a>
            </div>
        </div>
            
<script src="../js/script.js"></script>
<?php
include 'dbdetails.php';

//Index statement
$selectStm = "SELECT c.*, s.StoreName, s.Logo, s.Website FROM coupon c, store s WHERE s.StoreID = '6' AND c.StoreID = '6' AND c.End_Date >=curdate() ORDER BY c.End_Date DESC";
$query = mysqli_query($conn, $selectStm);
    while ($coupon = mysqli_fetch_array($query)) {
        ?>
        <div class="card coupon-card mx-auto my-2 shadow">
                <div class="col">
                    <div class="card-body">
                        <a href="<?php echo $coupon["Website"];?>" class="float-right" target="_blank">Visit Site <img src="/img/external-link-symbol.svg" alt="external" height="20" width="20"></a>
                        <img src="<?php echo $coupon["Logo"]; ?>" width="40" class="rounded-pill shadow float-left border mr-2" alt="store-logo">
                        <p class="card-text text-uppercase mx-2 py-2" style="text-shadow:.5px .5px 1.5px black;"><?php echo $coupon["StoreName"]; ?></p>
                        <span id="<?php echo 'c' . $coupon["CouponID"] ?>" hidden><?php echo $coupon["Code"] ?></span>
                        <h5 class="card-title text-uppercase"><?php echo $coupon["Code"]; ?></h5>
                        <p class="card-text"><?php echo $coupon["Description"]; ?></p>
                        <p class="card-text"><small class="text-muted">Expires <?php echo $coupon["End_Date"]; ?></small></p>
                        <button class="btn btn-success coupon-copy mr-2 mr-lg-3 mt-3 " onclick='copy(<?php echo "c" . $coupon["CouponID"] ?>.id)'>
                            Copy Coupon
                        </button>
                        <div class="picture float-right">
                            <a href='domino.php?type=like&id=<?php echo $coupon['CouponID']?>'> <img src="/img/like.svg" alt="like coupon" height="20" width="20"></a>
                            <a href='domino.php?type=dislike&id=<?php echo $coupon['CouponID']?>'> <img src="/img/dislike.svg" alt="dislike coupon" height="20" width="20" class = "ml-5"></a>
                            <?php 
                            $Totalquery = "SELECT COUNT(*) FROM coupon_impression WHERE CouponID=".$coupon['CouponID']."";
                            $Totalresult = mysqli_query($conn, $Totalquery);
                            $row = $Totalresult->fetch_row();
                            $Total=$row[0];
                            $Likes=0;
                            $Percentage=0;
                            $Likesquery = "SELECT COUNT(*) FROM coupon_impression WHERE CouponID='".$coupon['CouponID']."' AND isLike='1'";
                            $Likesresult = mysqli_query($conn, $Likesquery);
                            $row2 = $Likesresult->fetch_row();
                            $Likes=$row2[0];     
                            if($Total>0){
                            $Percentage=($Likes/$Total)*100;
                            } else{
                            $Percentage=0;
                            }
                            echo "<p class='card-text text-uppercase'> ".ceil($Percentage)."% Success</p>";
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php
    }
?>
        </div>
    </div>
    
    <?php
    include 'dbdetails.php';
    $selectStm = "SELECT f.* FROM favorites f WHERE f.UserID = $id AND f.StoreID = '6'";
    $queryAll = mysqli_query($conn, $selectStm);
    if($_SERVER['REQUEST_METHOD'] == "POST" and isset($_POST['removeFav'])) {
        if (mysqli_num_rows($queryAll) == 0){
            echo 'alert("Store already removed")';
        }else {
       $sql = "DELETE FROM favorites WHERE UserID = $id AND StoreID = '6'";
       $query = mysqli_query($conn, $sql);
       echo "<meta http-equiv='refresh' content='1'>";
        }
    }
    else if ($_SERVER['REQUEST_METHOD'] == "POST" and isset($_POST['addFav'])) {
        if (mysqli_num_rows($queryAll) > 0){
            echo 'alert("Store already added")';
        }else {
       $sql = "INSERT INTO favorites (UserID, StoreID) VALUES ('$id', '6')";
       $query = mysqli_query($conn, $sql);
       echo "<meta http-equiv='refresh' content='1'>";
        }
    }
?>
<?php require 'feedback.php'; ?>
        <!-- Bootstrap & Personal CSS -->
        <link rel="stylesheet" href="/css/bootstrap.min.css">
        <link rel="stylesheet" href="/css/style.css">
        <script src="jquery-3.5.1.min.js"></script>
        <?php require 'footer.php';?>
</body>

</html>