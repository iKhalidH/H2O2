<?php
require('dbdetails.php');
session_start();
if (isset($_SESSION['id'])) {
    $id=$_SESSION['id'];
    $sql="SELECT * FROM technician WHERE TechnicianID = $id";
    $query=mysqli_query($conn, $sql);
    $result=mysqli_fetch_array($query);
    if (is_null($result)) {
        echo "<script>alert('Unauthorized Access')</script>";
        header('location: ../index.php');
    }
} else {
    echo "<script>alert('Unauthorized Access')</script>";
    header('location: ../index.php');
    die();
}
?>
<!-- Sidebar -->
<div class="bg-light border-right" id="sidebar-wrapper">
    <div class="sidebar-heading mt-2">Technician Panel</div>
        <div class="list-group list-group-flush">
            <a class="list-group-item list-group-item-action border-bottom"href="/index.php">
                <div class="float-left ml-1">
                    <img width="15" src="/img/home.svg" alt="logout">
                    Home
                </div>
            </a>
            <a class="list-group-item list-group-item-action" href="requestTech.php">
                <div class="float-left">    
                    <img width="20" src="/img/requestIcon.svg" alt="coupon">
                    Requests
                </div>
            </a>
        </div>
    </div>
    <!-- /#sidebar-wrapper -->



