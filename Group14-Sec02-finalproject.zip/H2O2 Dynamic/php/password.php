<?php 
session_start();
         if(!isset($_SESSION['name'])){
echo "You are not authorized to enter this page";
exit;                
  }
  $id=$_SESSION['id'];
?>
<?php require 'dbdetails.php';?>

        
        <!-- Bootstrap & Personal CSS -->
        <link rel="stylesheet" href="/css/bootstrap.min.css">
        <link rel="stylesheet" href="/css/style.css">
<script src="jquery-3.5.1.min.js"></script>

        <title>Profile</title>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="keywords" content="Coupon, Yousef, Mowfaq, Khalid, H2O2, Offer, deal, shopping, shop">
    <meta name="description" content="A tailormade experience for your shopping leasiure where you may find all kinds of coupons and offers that will fulfill your needs">
    <meta name="author" content="Yousef Taj, Khalid AlAmro, Mowfaq Wale">
    <link rel="icon" href="img/TabIcon.svg">
    <title>Change Password</title>
    
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/adminStyle.css">
</head>
<body>

        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
        <script src="tabs.js"></script>
        <!-- JavaScript Search Function -->
        <script src="js/UserSearch.js"></script>
    
        <div class="d-flex" id="wrapper">

        <?php
            require('sidenavuser.php');
        ?>

        <!-- Page Content -->
        <div id="page-content-wrapper">

            <nav class="navbar navbar-expand-lg navbar-light bg-light pb-2 border-bottom">
                <span class="navbar-toggler-icon" id="menu-toggle"></span>

                <a class="navbar-brand mx-auto" href="../index.php"><img src="../img/h202logo.svg" width="50" alt="Logo">H2O2</a>
            </nav>

                <form class="form w-100" action="" method="POST" class="mt-2 mx-auto" name="form">
                    <div class="mt-2 mx-auto w-50 justify-content-center">
                    <div class="form-group">
                        <label for="email">Email address</label>
                        <input type="email" placeholder="Enter your email address" class="form-control" id="email"
                            name="email" aria-describedby="old email" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Old password</label>
                        <input type="password" placeholder="Enter your old password" class="form-control" id="password"
                            name="password" aria-describedby="old password" required>
                    </div>
                    <div class="form-group">
                        <label for="password">New Password</label>
                        <input type="password" placeholder="Enter your new password" class="form-control" id="password2"
                            name="password2" aria-describedby="new password" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Confirm Password</label>
                        <input type="password" placeholder="Confirm your password" class="form-control" id="password3"
                            name="password3" aria-describedby="confirm password" required>
                    </div>

                    <div class="form-group mx-auto text-center">
                        <button type="Submit" name="submit" class="btn btn-primary btn-lg text-center">Change password</button> 
            </div>
            </div>
                </form>
                <?php
                if($_SERVER['REQUEST_METHOD']=='POST'){
                require("dbdetails.php");
     $email=$_POST['email'];
     $password=$_POST['password'];
     $newpassword=$_POST['password2'];
     $confirmpassword=$_POST['password3'];
if ($newpassword==$confirmpassword){
     if($newpassword!=$password){
     $check = "SELECT * FROM users WHERE ID='$id'";
     $result1 = mysqli_query($conn, $check);
     $row1 = mysqli_fetch_array($result1);
     if ($row1['Email']=="$email" && password_verify($password, $row1['Password'])){
        $hashedpassword = password_hash($newpassword, PASSWORD_BCRYPT);
        $change = "UPDATE users SET Password='$hashedpassword' WHERE ID='$id'";
        $result2 = mysqli_query($conn, $change);
     } else{
         echo "entered information is not correct";
     }
    } else{
        echo "new password and old password must not be the same";
    }
} else {
    echo "new password and confirm password must be the same";
}
                }
                ?>
                    </div>
                    </div>
                </form>    
    
        </div>
        <!-- /#wrapper -->

        <!-- Bootstrap core JavaScript -->
        <script src="vendor/jquery/jquery.min.js"></script>
        <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

        <!-- Menu Toggle Script -->
        <script>
            $("#menu-toggle").click(function(e) {
            e.preventDefault();
            $("#wrapper").toggleClass("toggled");
            });
        </script>   
    </body>
</html>

