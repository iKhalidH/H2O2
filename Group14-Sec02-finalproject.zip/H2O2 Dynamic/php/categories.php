<?php require 'header.php';?>
<!doctype html>
<html lang="en">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="keywords" content="Coupon, Yousef, Mowfaq, Khalid, H2O2, Offer, deal, shopping, shop">
        <meta name="description" content="A tailormade experience for your shopping leasiure where you may find all kinds of coupons and offers that will fulfill your needs">
        <meta name="author" content="Yousef Taj, Khalid AlAmro, Mowfaq Wale">
        <link rel="icon" href="img/TabIcon.svg">
        
        <!-- Bootstrap & Personal CSS -->
        <link rel="stylesheet" href="/css/bootstrap.min.css">
        <link rel="stylesheet" href="/css/style.css">
        <script src="jquery-3.5.1.min.js"></script>

        <title>H2O2 Coupon - Categories</title>
    </head>

    <body>
        
        <!-- List of categories on website -->
        <div class="container fade-in">
        <div class="row mx-auto justify-content-center">
            <h1 class="display-4 mx-auto align-middle py-3">
                Categories
            </h1>
        </div>
        <hr>
        <div class="row text-center align-content-center">
                <div class="col-md-4 col-5 mx-auto">
                <a href="electronics.php"><img src="../img/desktop.svg" width="100" height="100"> <p>Electronics</p></a>
                </div>
                <div class="col-md-4 col-5 mx-auto">
                <a href="shoes.php"><img src="../img/sneakers.svg" width="100" height="100"><p>Shoes</p></a>
                </div>
                <div class="col-md-4 col-5 mx-auto">
                <a href="Travelandtourism.php"><img src="../img/plane.svg" width="100" height="100"><p>Travel & Hotels</p></a>
                </div>
                <div class="col-md-4 col-5 mx-auto">
                <a href="delivery.php"><img src="../img/delivery.svg" width="100" height="100"><p>Delivery</p></a>
                </div>
                <div class="col-md-4 col-5 mx-auto">
                <a href="fashion.php"><img src="../img/fashion.svg" width="100" height="100"><p>Fashion</p></a>
                </div>
                <div class="col-md-4 col-5 mx-auto">
                <a href="skinCare.php"><img src="../img/skincare.svg" width="100" height="100"><p>Health & Beauty</p></a>
                </div>
            </div>
        </div>
        <?php require 'footer.php';?>
  </body>
</html>
