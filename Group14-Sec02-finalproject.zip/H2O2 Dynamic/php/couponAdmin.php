<?php
//If coupon add button was added
if (isset($_POST["couponAdd"])) {
    require_once 'dbdetails.php';
    $date =  $_POST["End_Date"];
    $desc =  $_POST["Description"];
    $key =  $_POST["Keyword"];
    $store =  $_POST["StoreID"];
    $code =  $_POST["Code"];

    $addStm = "INSERT INTO coupon (End_Date, Description, Keyword, StoreID, Code) VALUES('$date','$desc','$key','$store','$code');";
    $addQuery = mysqli_query($conn, $addStm);
    if ($addQuery) {
        header("location: couponAdmin.php");
    } else {
        echo '<script>alert("Failed to add coupon")</script>';
    }
}

//If the delete button was triggered
if (isset($_POST["delete"])) {
    require_once 'dbdetails.php';
    $id = $_POST["CouponID"];
    echo $id;
    $deletestm = "DELETE FROM coupon WHERE CouponID = $id";
    $deletequery = mysqli_query($conn, $deletestm);
    if ($deletequery) {
        header("location: couponAdmin.php");
    } else {
        echo '<script>alert("Failed to delete coupon")</script>';
    }
}

//If the admin removed expired coupons
if(isset($_POST["removeExpired"])) {
    require_once 'dbdetails.php';
    $removeStm = "DELETE FROM coupon WHERE end_date < CURRENT_DATE;";
    $query = mysqli_query($conn,$removeStm);
    if($query) {
        header("location: couponAdmin.php");
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ADMIN PANEL</title>
    <link rel="icon" href="/img/TabIcon.svg">
    
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="/css/adminStyle.css">
</head>

<body>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    <script src="tabs.js"></script>
    <!-- JavaScript Search Function -->
    <script src="/js/SearchFunctions.js"></script>
   
    <div class="d-flex" id="wrapper">
    
    <?php
        require('sidenavAdmin.php');
    ?>

    <!-- Page Content -->
    <div id="page-content-wrapper">

        <nav class="navbar navbar-expand-lg navbar-light bg-light pb-2 border-bottom">
            <span class="navbar-toggler-icon" id="menu-toggle"></span>

            <a class="navbar-brand mx-auto" href=""><img src="/img/h202logo.svg" width="50" alt="Logo">H2O2 Dashboard</a>
        </nav>
        
        <nav class="navbar navbar-dark bg-dark d-lg-none">
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <div class="navbar-nav">
                    <a class="nav-link mx-auto" data-toggle="modal" data-target="#addForm">
                        New Coupon
                    </a>

                    <div class="nav-link mx-auto">
                        <form action="couponAdmin.php" method="POST">
                            <a class=" mx-auto" type="submit" name="removeExpired" onclick="confirm('Are you sure you want to remove all expired coupons?')">
                            Remove Expired Coupons
                            </a>
                        </form>
                    </div>
                </div>
            </div>

            <button class="navbar-toggler mx-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
        </nav>

        <nav class="navbar navbar-expand-lg align-content-center">                
            <div class="nav-item d-none d-lg-block">
                <button class="btn btn-add" data-toggle="modal" data-target="#addForm">New Coupon</button>
            </div>
            
            <form class="form-inline w-100 mx-auto my-2 my-lg-0">
                <div class="input-group mt-2 mx-auto w-75">
                    <input class="form-control mx-auto"type="search" placeholder="Search Coupons" id="couponSearch" onkeyup="search()">
                    <select class="nav-item dropdown mx-auto" name="searchOption" id="couponSearchOpt">
                        <option value="0">ID</option>
                        <option value="4">Store</option>
                        <option value="2">Keyword</option>
                    </select>
                </div>
            </form>
            
            <div class="nav-item d-none d-lg-block">
                <form action="couponAdmin.php" method="POST"><button class="btn btn-danger" type="submit" name="removeExpired" onclick="confirm('Are you sure you want to remove all expired coupons?')" alt="Remove Expired Coupons" 
                ><img src="/img/danger.svg" width="20"></button>
            </form>
            </div>
        </nav>

        <div class="container mx-auto pb-4 pt-2">
            <div class="container mx-auto pt-2">
                <div class="table-responsive rounded-table shadow">
                    <table class="table table-hover" id="tb">
                        <thead class="thead text-light shadow">
                            <tr>
                                <th scope="col" >ID</th>
                                <th scope="col" >Expiration</th>
                                <th scope="col" >Description</th>
                                <th scope="col" >Tag</th>
                                <th scope="col" >Store</th>
                                <th scope="col" >Code</th>
                                <th scope="col" >Edit</th>
                                <th scope="col" >Delete</th>
                            </tr>
                        </thead>
                        <?php

                        //Generates coupon table
                        require_once 'dbdetails.php';
                        $couponSelect = "SELECT c.*, s.StoreName FROM coupon c, store s WHERE c.StoreID = s.StoreID ORDER BY c.CouponID;";
                        $query = mysqli_query($conn, $couponSelect);
                        if (mysqli_num_rows($query) > 0) {
                            while ($tb = mysqli_fetch_array($query)) {
                        ?>
                            <tbody>
                                <tr>
                                    <td><?php echo $tb["CouponID"]; ?></td>
                                    <td><?php echo $tb["End_Date"]; ?></td>
                                    <td><?php echo $tb["Description"]; ?></td>
                                    <td><?php echo $tb["Keyword"]; ?></td>
                                    <td><?php echo $tb["StoreName"]; ?></td>
                                    <td><?php echo $tb["Code"]; ?></td>
                                    <td>
                                        <form action="tableInc/coupon.editForm.php" method="POST">
                                            <input type="hidden" name="CouponID" value="<?php echo $tb["CouponID"]; ?>">
                                            <input type="hidden" name="StoreName" value="<?php echo $tb["StoreName"]; ?>">
                                            <input type="hidden" name="End_Date" value="<?php echo $tb["End_Date"]; ?>">
                                            <input type="hidden" name="Description" value="<?php echo $tb["Description"]; ?>">
                                            <input type="hidden" name="Keyword" value="<?php echo $tb["Keyword"]; ?>">
                                            <input type="hidden" name="StoreID" value="<?php echo $tb["StoreID"]; ?>">
                                            <input type="hidden" name="Code" value="<?php echo $tb["Code"]; ?>">
                                            <button class="btn btn-edit" type="submit" name="edit"><img src="/img/pencil.svg" alt="edit" width="20"></button>
                                        </form>

                                    </td>
                                    <td>
                                        <!-- Delete Coupon -->
                                        <form action="couponAdmin.php" method="POST">
                                            <input type="hidden" name="CouponID" value="<?php echo $tb["CouponID"]; ?>">
                                            <button type="submit" class="btn btn-danger shadow" name="delete" onclick="return confirm('Are you sure you wanna delete <?php echo 'CouponID: ' . $tb['CouponID']; ?>');"><img src="/img/trash.svg" alt="delete" width="20"></button>
                                        </form>
                                    </td>
                                </tr>
                        <?php
                //Close brackets
                        }
                    }
                        ?>
                            </tbody>
                </table>
            </div>
        </div>

        </div>
        <!-- Modal to add to Coupon Table -->
        <div class="modal fade mx-auto" id="addForm" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Add</h5>

                    </div>
                    <div class="modal-body">
                        <form action="couponAdmin.php" id="form" method="POST">
                            <input required type="date" name="End_Date" id="end">
                            <input type="text" name="Description" placeholder="Description">
                            <input type="text" name="Keyword" placeholder="Keyword">
                            <select required name="StoreID" id="">
                                <option value="">Select Store</option>
                                <?php
                                include 'dbdetails.php';
                                $storestm = "SELECT * FROM store;";
                                $storeQuery = mysqli_query($conn, $storestm);

                                while ($stbl = mysqli_fetch_array($storeQuery)) {
                                    echo '<option value="' . $stbl["StoreID"] . '">' . $stbl["StoreName"] . '</option>';
                                }
                                ?>
                            </select>
                            <input required type="text" name="Code" placeholder="Code">
                            <div class="modal-footer">
                                <button type="submit" name="couponAdd" class="btn btn-primary">Add to table</button>
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
    <!-- /#page-content-wrapper -->

  </div>
  <!-- /#wrapper -->

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Menu Toggle Script -->
  <script>
    $("#menu-toggle").click(function(e) {
      e.preventDefault();
      $("#wrapper").toggleClass("toggled");
    });
  </script>   
    </body>
</html>