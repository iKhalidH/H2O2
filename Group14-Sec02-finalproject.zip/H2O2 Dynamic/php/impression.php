<?php
    require('/php/dbdetails.php');
    
    if($_POST['action'] == 'call_this') {
        $id=$_POST['coupon'];
        $imp=$_POST['impression'];
        $user=$_SESSION['id'];
        
        $sql = 'SELECT * FROM coupon_impression WHERE UserID=$user AND CouponID=$id';
        $query = mysqli_query($conn, $sql);
        
        if (!empty($query)) {
            $sql = 'UPDATE coupon_impression SET isLike=$imp WHERE UserID=$user AND CouponID=$id';
            mysqli_query($conn, $sql);
        } else {
            $sql = 'INSERT INTO coupon_impression (CouponID, UserID, isLike) VALUES ("$user","$id", "$imp")';
            mysqli_query($conn, $sql);
        }
    }
?>