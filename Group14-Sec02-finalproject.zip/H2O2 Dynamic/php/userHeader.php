        <?php
         session_start();
         if(!empty($_SESSION['id'])){
        $ID=$_SESSION['id'];
         }
         $username="";
         if(!empty($_SESSION['name'])){
        $username=$_SESSION['name'];
         }
         ?>
        <script src="/js/bootstrap.bundle.min.js"></script>

        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
            integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
            crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"
            integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN"
            crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js"
            integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s"
            crossorigin="anonymous"></script>

        <!-- Navigation bar for website -->
        <nav class="navbar navbar-expand-lg navbar-light fade-in-header">
            
            <!-- Collapse button for when screen is too small to display elements correctly. Used to hide search bar and activate it with button -->
            <button class="btn navbar-toggler" type="button" data-toggle="collapse" data-target="#searchBarToggler"
                aria-controls="searchBarToggler" aria-expanded="false" aria-label="Toggle navigation">
                <img src="/img/magnifying-glass.svg" alt="search" width="30" height="30" loading="lazy">
            </button>  
            
            <!-- Logo of website. Doubles as a nav button to index page -->
            <a class="navbar-brand mx-auto" href="/index.php"><img src="/img/h202logo.svg" alt="H2O2logo" width="50" height="50" alt="" loading="lazy">
                H2O2 Coupon
            </a>
            
            <!-- Collapse button for when screen is too small to display elements correctly. Hides remaining elements and activates them through button -->
            <button class="btn navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarToggler"
                aria-controls="navbarToggler" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <!-- Categories, sign in and sign up buttons -->
            <div class="collapse navbar-collapse text-center mx-auto" id="navbarToggler">
                <?php if($username!=""):
                    $store = "SELECT Account_Status FROM users Where ID=".$_SESSION['id']."";
                    $result = mysqli_query($conn, $store);
                    $Account = mysqli_fetch_array($result);
                    if ($Account['Account_Status']==0){
                        session_destroy();
                        echo "<meta http-equiv='refresh' content='0'>";
 
                    }
                    $technician = "SELECT TechnicianID FROM technician WHERE TechnicianID=".$_SESSION['id']."";
                    $techniciancheck = mysqli_query($conn, $technician);
                    $row2 = mysqli_fetch_array($techniciancheck);
                     if($row2['TechnicianID']==$_SESSION['id']){
                    $usertype="technician";
                    } 
                    $admin = "SELECT AdminID FROM admin WHERE AdminID=".$_SESSION['id']."";
                    $admincheck = mysqli_query($conn, $admin);
                    $row3 = mysqli_fetch_array($admincheck);
                    if($row3['AdminID']==$_SESSION['id']){
                    $usertype="admin";
                    } 
                    echo '<!-- Nav Item - User Information -->
                        <a class="btn d-lg-none" data-toggle="collapse" href="#userCollapse" role="button" aria-expanded="false" aria-controls="collapseExample">
                            '. $username .'
                        </a>
                        <div class="collapse d-lg-none border-bottom" id="userCollapse">
                            <a class="btn" href="/php/name.php">
                                    <i class="fas fa-user fa-sm fa-fw text-gray-400"></i>
                                    Profile
                                </a>
                            <form action="" method="post">';
                                if($usertype=="technician"){
                                    echo "<input type='submit' class='btn' name='technician' value='Dashboard'>";
                                    }
                                else if($usertype=="admin"){
                                    echo "<input type='submit' class='btn' name='admin' value='Dashboard'>";
                                    }
                                echo '<hr>
                                <input type="submit" class="btn" name="logout" value="Sign Out">
                            </form>
                        </div>
                        <div class="nav-item d-lg-inline d-none dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline user-text">'. $username .'</span>
                                <img class="img-profile rounded-circle"
                                    src="../img/undraw_profile.svg" width="30px" height="30px">
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="/php/name.php">
                                    <i class="fas fa-user fa-sm fa-fw text-gray-400"></i>
                                    Profile
                                </a>
                                <form action="" method="post">'; 
                                    if(isset($usertype)){
                                        if($usertype=="technician"){
                                        echo "<input type='submit' class='dropdown-item' name='technician' value='Dashboard'>";
                                        }
                                        else if($usertype=="admin"){
                                        echo "<input type='submit' class='dropdown-item' name='admin' value='Dashboard'>";
                                        }
                                    }
                                echo '<div class="dropdown-divider"></div>
                                <input type="submit" class="dropdown-item" name="logout" value="Sign Out">
                                </form>
                            </div>
                        </div>';
                    ?>
                <div class="justify-content-center">
                    
                        </div>
                <?php else:?>
                        <a href="/html/signIn.html" class="btn nav-item">
                        <img src="/img/power-button.svg" class="" alt="search" width="15" height="15" loading="lazy">Sign In</a>
                    <a href="/html/signUp.html"> <button type="button" class="btn btn-success nav-item">Sign Up</button></a>
                <?php endif;?>
                        <?php
                        if($_SERVER['REQUEST_METHOD']=="POST" and isset($_POST['logout'])){
                            logout();
                        }
                        if($_SERVER['REQUEST_METHOD']=="POST" and isset($_POST['technician'])){
                            technician();
                        }
                        if($_SERVER['REQUEST_METHOD']=="POST" and isset($_POST['admin'])){
                            admin();
                        }
                        function logout(){
                            session_destroy();
                       echo "<meta http-equiv='refresh' content='0'>";
                        }
                        function technician(){
                            echo "<meta http-equiv='refresh' content='0;URL=php/Technician/technician.php'>";
                        }
                        function admin(){
                            echo "<meta http-equiv='refresh' content='0;URL=php/Admin/adminDash.php'>";
                            }
                        ?>
            </div>
        </nav>