<?php
//Adds into category table
if (isset($_POST["categoryAdd"])) {
    require_once 'dbdetails.php';
    $name = $_POST["Name"];
    $desc = $_POST["Category_Desc"];

    $addStm = "INSERT INTO category (Name, Category_Desc) VALUES('$name','$desc');";
    $addQuery = mysqli_query($conn, $addStm);

    if ($addQuery) {
        header("location: categoryAdmin.php");
    } else {
        echo '<script>alert("Failed to add category")</script>';
    }
}

//Delete category
if (isset($_POST["delete"])) {

    require_once 'dbdetails.php';

    $catid = $_POST["CatID"];
    $deleteStm = "DELETE FROM category WHERE CatID = '$catid';";
    $delQuery = mysqli_query($conn, $deleteStm);
    if ($delQuery) {
        header("location: categoryAdmin.php");
    } else {
        echo '<script>alert("Failed to remove category")</script>';
    }
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ADMIN PANEL</title>
    <link rel="icon" href="/img/TabIcon.svg">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="/css/adminStyle.css">
</head>

<body>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    <script src="tabs.js"></script>
    <!-- JavaScript Search Function -->
    <script src="/js/SearchFunctions.js"></script>

    <div class="d-flex" id="wrapper">

        <?php
        require('sidenavAdmin.php');
        ?>

        <!-- Page Content -->
        <div id="page-content-wrapper">

            <nav class="navbar navbar-expand-lg navbar-light bg-light pb-2 border-bottom">
                <span class="navbar-toggler-icon" id="menu-toggle"></span>

                <a class="navbar-brand mx-auto" href=""><img src="/img/h202logo.svg" width="50" alt="Logo">H2O2 Dashboard</a>
            </nav>

            <nav class="navbar navbar-dark bg-dark d-lg-none">
                <div class="navbar-nav mx-auto">
                    <a class="nav-link mx-auto" data-toggle="modal" data-target="#addForm">
                        New Category
                    </a>
                </div>
            </nav>

            <nav class="navbar navbar-expand-lg align-content-center">
                <button class="btn btn-add d-none d-lg-block" data-toggle="modal" data-target="#addForm">New Category</button>

                <form class="form-inline w-100 mx-auto my-2 my-lg-0">
                    <div class="input-group mt-2 mx-auto w-75">
                        <input class="form-control mx-auto" type="search" placeholder="Search Categories" id="couponSearch" onkeyup="search()">
                        <select class="nav-item dropdown mx-auto" name="searchOption" id="couponSearchOpt">
                            <option value="0">ID</option>
                            <option value="1">Name</option>
                            <option value="2">Description</option>
                        </select>
                    </div>
                </form>
            </nav>

            <div class="container pb-4 mx-auto pt-2">



                <div class="container mx-auto pt-2">
                    <div class="table-responsive rounded-table shadow">
                        <table class="table table-hover" id="tb">
                            <thead class="thead text-light shadow">
                                <tr>
                                    <th scope="col">Category ID</th>
                                    <th scope="col">Name</th>
                                    <th scope="col">Category Description</th>
                                    <th scope="col">Edit</th>
                                    <th scope="col">Delete</th>
                                </tr>
                            </thead>

                            <?php
                            require_once 'dbdetails.php';
                            $couponSelect = "SELECT * FROM category;";
                            $query = mysqli_query($conn, $couponSelect);
                            if (mysqli_num_rows($query) > 0) {
                                while ($tb = mysqli_fetch_array($query)) {



                            ?>
                                    <tbody>
                                        <tr>
                                            <td><?php echo $tb["CatID"]; ?></td>
                                            <td><?php echo $tb["Name"]; ?></td>
                                            <td><?php echo $tb["Category_Desc"]; ?></td>
                                            <td>
                                                <form action="tableInc/category.editForm.php" method="POST">
                                                    <input type="hidden" name="CatID" value="<?php echo $tb["CatID"]; ?>">
                                                    <input type="hidden" name="Name" value="<?php echo $tb["Name"]; ?>">
                                                    <input type="hidden" name="Category_Desc" value="<?php echo $tb["Category_Desc"]; ?>">
                                                    <button class="btn btn-edit" type="submit" name="edit"><img src="/img/pencil.svg" alt="edit" width="20"></button>
                                                </form>

                                            </td>
                                            <td>
                                                <form action="categoryAdmin.php" method="POST">
                                                    <input type="hidden" name="CatID" value="<?php echo $tb["CatID"]; ?>">
                                                    <button class="btn btn-danger shadow" type="submit" name="delete" onclick="return confirm('Are you sure you want to continue?');"><img src="/img/trash.svg" width="20" alt=""></button>
                                                </form>
                                            </td>
                                        </tr>
                                <?php

                                }
                            }
                                ?>
                                    </tbody>
                        </table>
                    </div>
                </div>

                <!-- Modal to add to CouponTable -->
                <div class="modal fade" id="addForm" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Add</h5>

                            </div>
                            <div class="modal-body">
                                <form action="categoryAdmin.php" id="form" method="POST">
                                    <input required type="text" name="Name" placeholder="Category Name">
                                    <input type="text" name="Category_Desc" placeholder="Category Description">
                                    <div class="modal-footer">
                                        <button type="submit" name="categoryAdd" class="btn btn-primary">Add to table</button>
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    </div>
                                </form>
                            </div>

                        </div>

                    </div>

                    </form>
                </div>

            </div>
            <!-- /#page-content-wrapper -->

        </div>
        <!-- /#wrapper -->

        <!-- Bootstrap core JavaScript -->
        <script src="vendor/jquery/jquery.min.js"></script>
        <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

        <!-- Menu Toggle Script -->
        <script>
            $("#menu-toggle").click(function(e) {
                e.preventDefault();
                $("#wrapper").toggleClass("toggled");
            });
        </script>
</body>

</html>