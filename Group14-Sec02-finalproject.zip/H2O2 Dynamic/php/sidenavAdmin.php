<?php
require('dbdetails.php');
session_start();
if (isset($_SESSION['id'])) {
    $id=$_SESSION['id'];
    $sql="SELECT * FROM admin WHERE AdminID = $id";
    $query=mysqli_query($conn, $sql);
    $result=mysqli_fetch_array($query);
    if (is_null($result)) {
        echo "<script>alert('Unauthorized Access')</script>";
        header('location: ../index.php');
    }
} else {
    echo "<script>alert('Unauthorized Access')</script>";
    header('location: ../index.php');
    die();
}
?>
<!-- Sidebar -->
<div class="bg-light border-right" id="sidebar-wrapper">
    <div class="sidebar-heading mt-2">Admin Panel</div>
        <div class="list-group list-group-flush">
            <a class="list-group-item list-group-item-action" href="/index.php">
                <div class="float-left">
                    <img width="20" src="/img/home.svg" alt="">
                    Home
                </div>
            </a>
            <a class="list-group-item list-group-item-action" href="couponAdmin.php">
                <div class="float-left">    
                    <img width="20" src="/img/CouponIcon.svg" alt="coupon">
                    Coupons
                </div>
            </a>
            <a class="list-group-item list-group-item-action" href="storeAdmin.php">
                <div class="float-left">    
                    <img width="20" src="/img/StoreIcon.svg" alt="">
                    Stores
                </div>
            </a>
            <a class="list-group-item list-group-item-action" href="categoryAdmin.php">
                <div class="float-left">
                    <img width="20" src="/img/CategoryIcon.svg" alt="">
                    Categories
                </div>
            </a>
            <a class="list-group-item list-group-item-action" href="adminList.php">
                <div class="float-left">
                    <img width="20" src="/img/adminIcon.svg" alt="">
                    Admins
                </div>
            </a>
            <a class="list-group-item list-group-item-action" href="technicianAdmin.php">
                <div class="float-left">
                    <img width="20" src="/img/techIcon.svg" alt="">
                    Technicians
                </div>
            </a>
            <a class="list-group-item list-group-item-action" href="userAdmin.php">
                <div class="float-left">
                    <img width="20" src="/img/userIcon.svg" alt="">
                    Users
                </div>
            </a>
            <a class="list-group-item list-group-item-action" href="requestAdmin.php">
                <div class="float-left">
                    <img width="20" src="/img/requestIcon.svg" alt="">
                    Requests
                </div>
            </a>
            <a class="list-group-item list-group-item-action" href="reportAdmin.php">
                <div class="float-left">
                    <img width="20" src="/img/profits.svg" alt="">
                    Report
                </div>
            </a>
        </div>
    </div>
    <!-- /#sidebar-wrapper -->
