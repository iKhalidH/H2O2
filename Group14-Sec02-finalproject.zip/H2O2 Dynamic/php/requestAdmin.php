<?php

//Removes request
if (isset($_POST["delete"])) {
    require_once 'dbdetails.php';
    $id = $_POST["ID"];
    $stm = "DELETE FROM request WHERE ID = '$id';";

    $query = mysqli_query($conn, $stm);
    if ($query) {
        header("location: requestAdmin.php");
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ADMIN PANEL</title>
    <link rel="icon" href="/img/TabIcon.svg">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="/css/adminStyle.css">
</head>

<body>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    <script src="tabs.js"></script>
    <!-- JavaScript Search Function -->
    <script src="/js/SearchFunctions.js"></script>
   
    <div class="d-flex" id="wrapper">

    <?php
        require('sidenavAdmin.php');
    ?>

    <!-- Page Content -->
    <div id="page-content-wrapper">

        <nav class="navbar navbar-expand-lg navbar-light bg-light pb-2 border-bottom">
            <span class="navbar-toggler-icon" id="menu-toggle"></span>

            <a class="navbar-brand mx-auto" href=""><img src="/img/h202logo.svg" width="50" alt="Logo">H2O2 Dashboard</a>
        </nav>
        
        <nav class="navbar navbar-expand-lg align-content-center">               
            <form class="form-inline w-100 mx-auto my-2 my-lg-0">
                <div class="input-group mt-2 mx-auto w-75">
                    <input class="form-control mx-auto"type="search" placeholder="Search Request" id="couponSearch" onkeyup="search()">
                    <select class="nav-item dropdown mx-auto" name="searchOption" id="couponSearchOpt">
                        <option value="0">User ID</option>
                        <option value="1">Title</option>
                        <option value="2">Technician ID</option>
                    </select>
                </div>
            </form>
        </nav>

        <div class="container mx-auto pt-2">
            <div class="container mx-auto pt-2">
                <div class="table-responsive rounded-table shadow">
                    <table class="table text-center table-hover" id="tb">
                        <thead class="thead text-light shadow">
                            <tr>
                                <th scope="col">Submitter User ID</th>
                                <th scope="col">Title</th>
                                <th scope="col">Reason</th>
                                <th scope="col">Address</th>
                                <th scope="col">Status</th>
                                <th scope="col">Technician ID</th>
                                <th scope="col">Delete Request</th>
                            </tr>
                        </thead>
                        <?php

                        //Generates coupon table
                        require_once 'dbdetails.php';
                        $requestSelect = "SELECT * FROM request";
        $query = mysqli_query($conn, $requestSelect);
        //Generates the list of requests
        if (mysqli_num_rows($query) > 0) {
            while ($tb = mysqli_fetch_array($query)) {
        ?>
                <tbody>
                    <tr>
                        <td><?php echo $tb["Submitter_ID"]; ?></td>
                        <td><?php echo $tb["Title"]; ?></td>
                        <td><?php echo $tb["Request_Desc"]; ?></td>
                        <td><?php echo $tb["Address"]; ?></td>
                        <td><?php echo statusCheck($tb["Status"]); ?></td>
                        <td class="text-center">
                            <form action="tableInc/request.assignForm.php" method="POST">
                                <input type="hidden" name="ID" value="<?php echo $tb["ID"]; ?>">
                                <?php echo TechnicianCheck($tb["Technician_ID"]); ?>
                            </form>
                        </td>
                        <td>

                            <form action="requestAdmin.php" method="POST">
                                <input type="hidden" name="ID" value="<?php echo $tb["ID"]; ?>">
                                <button class="btn btn-danger shadow" type="submit" name="delete" onclick="return confirm('Are you sure you want to continue?');"><img src="/img/trash.svg" width="20" alt=""></button>
                            </form>
                        </td>
                    </tr>
            <?php

            }
        }
            ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php

    //Checks the status, and gives a badge output
    function statusCheck($status)
    {
        if ($status == 'accepted') {
            return '<span class="text-uppercase text-success">Accepted</span>';
        } else if ($status == 'rejected') {
            return '<span class="text-uppercase text-danger">Rejected</span>';
        } else {
            return '<span class="text-uppercase text-info">Ongoing</span>';
        }
    }

    //Checks if a technician is assigned to a request
    function TechnicianCheck($technician)
    {
        if ($technician == '') {
            return '<button type="submit" name="assignBtn" class="btn btn-secondary">Assign Technician</button>';
        } else {
            $cell=$technician . '<button type="submit" name="assignBtn" class="btn btn-edit"><img src="/img/pencil.svg" width="20" alt=""></button>';
            return $cell;
        }
    }
    ?>
    </form>
    </div>

        </div>
        <!-- /#page-content-wrapper -->

    </div>
  <!-- /#wrapper -->

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Menu Toggle Script -->
  <script>
    $("#menu-toggle").click(function(e) {
      e.preventDefault();
      $("#wrapper").toggleClass("toggled");
    });
  </script>   
</body>