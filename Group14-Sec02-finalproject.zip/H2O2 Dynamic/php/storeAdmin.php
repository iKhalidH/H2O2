<?php
//Adds into store table
if (isset($_POST["storeAdd"])) {
    require_once 'dbdetails.php';
    $sname = $_POST["StoreName"];
    $logo = $_POST["Logo"];
    $catid = $_POST["CatID"];
    $web = $_POST["Website"];

    $addStm = "INSERT INTO store (StoreName, Logo, CatID, Website) VALUES('$sname','$logo','$catid','$web')";
    $addQuery = mysqli_query($conn, $addStm);
    if ($addQuery) {
        header('location: storeAdmin.php');
    } else {
        echo '<script>alert("Failed to add store")</script>';
    }
}

//Deletes from store table
if (isset($_POST["delete"])) {
    require_once 'dbdetails.php';
    $sid = $_POST["StoreID"];
    $deletestm = "DELETE FROM store WHERE StoreID = '$sid';";

    $delQuery = mysqli_query($conn, $deletestm);
    if ($delQuery) {
        header("location: storeAdmin.php");
    } else {
        echo '<script>alert("Failed to delete store")</script>';
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ADMIN PANEL</title>
    <link rel="icon" href="/img/TabIcon.svg">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="/css/adminStyle.css">
</head>

<body>
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
        <script src="tabs.js"></script>
        <!-- JavaScript Search Function -->
        <script src="/js/SearchFunctions.js"></script>
    
        <div class="d-flex" id="wrapper">

        <?php
            require('sidenavAdmin.php');
        ?>

        <!-- Page Content -->
        <div id="page-content-wrapper">

            <nav class="navbar navbar-expand-lg navbar-light bg-light pb-2 border-bottom">
                <span class="navbar-toggler-icon" id="menu-toggle"></span>

                <a class="navbar-brand mx-auto" href=""><img src="/img/h202logo.svg" width="50" alt="Logo">H2O2 Dashboard</a>
            </nav>

            <nav class="navbar navbar-dark bg-dark d-lg-none">
                <div class="navbar-nav mx-auto">
                    <a class="nav-link mx-auto" data-toggle="modal" data-target="#addForm">
                        New Store
                    </a>
                </div>
            </nav>

            <nav class="navbar navbar-expand-lg align-content-center">
                <button class="btn btn-add d-none d-lg-block" data-toggle="modal" data-target = "#addForm">New Store</button>  

                <form class="form-inline w-100 mx-auto my-2 my-lg-0">
                <div class="input-group mt-2 mx-auto w-75">
                    <input class="form-control mx-auto"type="search" placeholder="Search Stores" id="couponSearch" onkeyup="search()">
                    <select class="nav-item dropdown mx-auto" name="searchOption" id="couponSearchOpt">
                        <option value="0">ID</option>
                        <option value="1">Store</option>
                        <option value="2">Keyword</option>
                    </select>
                </div>
            </form>
            </nav>

            <div class="container mx-auto pb-4 pt-2">
                <div class="table-responsive rounded-table shadow">
                    <table class="table table-hover" id="tb">
                        <thead class="thead text-light shadow">
                            <th scope="col">Store ID</th>
                            <th scope="col">Store Name</th>
                            <th scope="col">Category</th>
                            <th scope="col">Website</th>
                            <th scope="col">Edit</th>
                            <th scope="col">Delete</th>
                        </thead>
                <?php
                require_once 'dbdetails.php';
                $storeSelect = "SELECT s.*, c.Name FROM store s, category c WHERE s.CatID = c.CatID";
                $query = mysqli_query($conn, $storeSelect);

                //Generates store table
                if (mysqli_num_rows($query) > 0) {
                    while ($tb = mysqli_fetch_array($query)) {
                ?>

                        <tbody>
                            <tr>
                                <td><?php echo $tb["StoreID"]; ?></td>
                                <td><?php echo $tb["StoreName"]; ?></td>
                                <td><?php echo $tb["Name"]; ?></td>
                                <td><?php echo $tb["Website"]; ?></td>
                                <td>
                                    <form action="tableInc/store.editForm.php" method="POST">
                                        <input type="hidden" name="StoreID" value="<?php echo $tb["StoreID"]; ?>">
                                        <input type="hidden" name="StoreName" value="<?php echo $tb["StoreName"]; ?>">
                                        <input type="hidden" name="Logo" value="<?php echo $tb["Logo"]; ?>">
                                        <input type="hidden" name="CatID" value="<?php echo $tb["CatID"]; ?>">
                                        <input type="hidden" name="Name" value="<?php echo $tb["Name"]; ?>">
                                        <input type="hidden" name="Website" value="<?php echo $tb["Website"]; ?>">
                                        <button class="btn btn-edit" type="submit" name="edit"><img src="/img/pencil.svg" width="20" alt=""></button>
                                    </form>

                                </td>
                                <td>
                                    <form action="storeAdmin.php" method="POST">
                                        <input type="hidden" name="StoreID" value="<?php echo $tb["StoreID"]; ?>">
                                        <button class="btn btn-danger shadow" type="submit" name="delete" onclick="return confirm('Are you sure you want to continue?');"><img src="/img/trash.svg" width="20" alt=""></button>
                                    </form>
                                </td>
                            </tr>
                    <?php

                    }
                }
                    ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Modal to add to CouponTable -->
            <div class="modal fade" id="addForm" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Add</h5>

                        </div>
                        <div class="modal-body">
                            <form action="storeAdmin.php" id="form" method="POST">
                                <input required type="text" name="StoreName" placeholder="Store Name">
                                <input type="text" name="Logo" placeholder="Logo">
                                <select required name="CatID" id="">
                                    <option value="">Select Category</option>
                                    <?php
                                    include 'dbdetails.php';
                                    $storestm = "SELECT * FROM category;";
                                    $catQuery = mysqli_query($conn, $storestm);

                                    while ($stbl = mysqli_fetch_array($catQuery)) {
                                        echo '<option value="' . $stbl["CatID"] . '">' . $stbl["Name"] . '</option>';
                                    }
                                    ?>
                                </select>
                                <input type="text" name="Website" placeholder="Store Website">
                                <div class="modal-footer">
                                    <button type="submit" name="storeAdd" class="btn btn-primary">Add to table</button>
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                </div>
                            </form>
                        </div>

                    </div>

                </div>
            </div>
        </div>
        <!-- /#wrapper -->

        <!-- Bootstrap core JavaScript -->
        <script src="vendor/jquery/jquery.min.js"></script>
        <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

        <!-- Menu Toggle Script -->
        <script>
            $("#menu-toggle").click(function(e) {
            e.preventDefault();
            $("#wrapper").toggleClass("toggled");
            });
        </script>   
    </body>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>

</html>