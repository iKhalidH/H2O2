<?php include 'dbdetails.php';?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TECHNICIAN PAGE</title>
    
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="/css/adminStyle.css">
    <link rel="stylesheet" href="/css/style.css">
</head>
<body>
    <body>
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
        <script src="tabs.js"></script>
        <!-- JavaScript Search Function -->
        <script src="/js/SearchFunctions.js"></script>
    
        <div class="d-flex" id="wrapper">

        <?php
            require('sidenavtechnician.php');
        ?>

        <!-- Page Content -->
        <div id="page-content-wrapper">

            <nav class="navbar navbar-expand-lg navbar-light bg-light pb-2 border-bottom">
                <span class="navbar-toggler-icon" id="menu-toggle"></span>

                <a class="navbar-brand mx-auto" href=""><img src="/img/h202logo.svg" width="50" alt="Logo">H2O2 Dashboard</a>
            </nav>

            <nav class="navbar navbar-expand-lg fade-in bg-dark navbar-dark align-content-center">           
                <form class="form-inline w-100 mx-auto my-2 my-lg-0">
                    <div class="input-group mt-2 mx-auto w-75">
                    <input class="form-control mx-auto"type="search" placeholder="Search Requests" id="couponSearch" onkeyup="search()">
                        <select class="nav-item dropdown mx-auto" name="searchOption" id="couponSearchOpt">
                            <option value="0">User ID</option>
                            <option value="1">Title</option>
                        </select>
                    </div>
                </form>
            </nav>
            
            <?php 
                //Displaying error
                $msg = $_SERVER["REQUEST_URI"];
                    if(strpos($msg, "?Error")) {
                        echo "<script type='text/javascript'>alert(\"Failed to commit change\");</script>";
                }
            ?>    

            <div class="container fade-in mx-auto pt-2">
                <div class="table-responsive rounded-table shadow">
                <table class="table table-hover" id="tb">
                    <thead class="thead text-light shadow">
                        <th>Submitter User ID</th>
                        <th>Title</th>
                        <th>Reason</th>
                        <th>Address</th>
                        <th>Status</th>
                        <th>Reply</th>
                    </thead>
                    <?php 
                    require_once 'dbdetails.php';
                    $id = $_SESSION['id'];
                    $requestSelect = "SELECT * FROM request WHERE Technician_ID = $id";
                    $query = mysqli_query($conn, $requestSelect);
                    if(mysqli_num_rows($query) > 0) {
                        while($tb = mysqli_fetch_array($query)) {
                            
                    ?>
                <tbody>
                    <tr>
                        <td><?php echo $tb["Submitter_ID"]; ?></td>
                        <td><?php echo $tb["Title"]; ?></td>
                        <td><?php echo $tb["Request_Desc"]; ?></td>
                        <td><?php echo $tb["Address"]; ?></td>
                        <td>
                            <?php echo statusCheck($tb["Status"]); ?>
                        </td>
                        <td>
                            <form action="tableInc/request.form.php" method="POST">
                                <input type="hidden" name = "ID" value="<?php echo $tb["ID"];?>">
                                <input type="hidden" name = "Title" value="<?php echo $tb["Title"];?>">
                                <input type="hidden" name = "Desc" value="<?php echo $tb["Request_Desc"];?>">
                                <input type="hidden" name = "Address" value="<?php echo $tb["Address"];?>">
                                <button type="submit" name="reply" class="btn btn-info">Reply</button>
                            </form>
                        </td>
                    </tr>
                    <?php 
                    
                }
            }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
<?php
function statusCheck($status) {
    if($status == '1') {
        return '<span class="text-uppercase text-success">Accepted</span>';
    }
    else if ($status == '2') {
        return '<span class="text-uppercase text-danger">Rejected</span>';
    }
    else {
        return '<span class="text-uppercase text-info">Ongoing</span>';
    }
}
?>
        </div>
        <!-- /#wrapper -->

        <!-- Bootstrap core JavaScript -->
        <script src="vendor/jquery/jquery.min.js"></script>
        <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

        <!-- Menu Toggle Script -->
        <script>
            $("#menu-toggle").click(function(e) {
            e.preventDefault();
            $("#wrapper").toggleClass("toggled");
            });
        </script>   
    </body>
</html>