function alert(msg) {
    alert(msg);
}

function copy(x) {
    const str = document.getElementById(x).innerText;
    const el = document.createElement('textarea');
    el.value = str;
    el.setAttribute('readonly', '');
    el.style.position = 'absolute';
    document.body.appendChild(el);
    el.select();
    document.execCommand('copy');
    document.body.removeChild(el);


}

function like(coupon, impression) {
    $.ajax({
        type: "POST",
           url: '/php/impression.php',
           data:{action:'call_this'},
           success:function(html) {
             // animate like button
           }
    })
}

$(document).on("scroll", function() {
var pageTop = $(document).scrollTop();
var pageBottom = pageTop + $(window).height();
var tags = $(".tag");

for (var i = 0; i < tags.length; i++) {
var tag = tags[i];

if ($(tag).position().top < pageBottom) {
$(tag).addClass("visible");
} else {
$(tag).removeClass("visible");
}
}
})