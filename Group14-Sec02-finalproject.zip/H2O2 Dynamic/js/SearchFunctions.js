function search() {
    let searchVal = document.getElementById("couponSearchOpt").value;

    var input, filter, table, tr, td, i, txtValue;
    input = document.getElementById("couponSearch");
    filter = input.value.toUpperCase();
    table = document.getElementById("tb");
    tr = document.getElementsByTagName("tr");

    for (i = 0; i < tr.length; i++) {
        td = tr[i].getElementsByTagName("td")[searchVal];
        if (td) {
        txtValue = td.textContent || td.innerText;
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
            tr[i].style.display = "";
            } 
        else {
            tr[i].style.display = "none";
            }
        }
    }
}